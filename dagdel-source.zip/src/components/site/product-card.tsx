"use client";

import { Leaf, ShoppingBag } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

import type { ProductRecord } from "@/lib/site-data";
import { cn, formatCurrency, hasNumericPrice } from "@/lib/utils";

import { AddToCartButton } from "./add-to-cart-button";

type ProductCardProps = {
  product: ProductRecord;
  className?: string;
};

export function ProductCard({ product, className }: ProductCardProps) {
  const isRequestOnly =
    !hasNumericPrice(product.priceText) || product.availability.toLowerCase().includes("нет в наличии");
  return (
    <article className={cn("group panel flex h-full flex-col overflow-hidden p-1.5 sm:p-3", className)}>
      <Link
        className="relative block aspect-square overflow-hidden rounded-[20px] bg-white/80 sm:aspect-[4/4.6] sm:rounded-[28px]"
        href={product.href}
      >
        {product.mainImage ? (
          <Image
            alt={product.title}
            className="object-cover transition duration-500 group-hover:scale-[1.03]"
            fill
            sizes="(max-width: 768px) 50vw, (max-width: 1280px) 50vw, 25vw"
            src={product.mainImage}
          />
        ) : null}
        <div className="absolute inset-x-2 top-2 flex items-center gap-2 sm:inset-x-3 sm:top-3 sm:justify-between">
          <span className="inline-flex items-center gap-1 rounded-full bg-white/88 px-2 py-1 text-[10px] font-semibold leading-none text-[var(--color-primary-deep)] shadow-sm backdrop-blur sm:gap-2 sm:px-3 sm:text-xs">
            <Leaf className="h-3 w-3 sm:h-3.5 sm:w-3.5" />
            <span className="hidden sm:inline">Натуральный состав</span>
            <span className="sm:hidden">Натур.</span>
          </span>
          <span className="hidden rounded-full bg-[var(--color-foreground)]/82 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-white sm:inline-flex">
            {product.categoryNames[0] ?? "Каталог"}
          </span>
        </div>
      </Link>

      <div className="flex flex-1 flex-col gap-2 px-1 pb-1 pt-2.5 sm:gap-3 sm:px-2 sm:pb-2 sm:pt-4">
        <div className="space-y-1.5 sm:space-y-2">
          <div className="min-w-0 space-y-1.5 sm:space-y-2">
              <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-[var(--color-primary-deep)]/70 sm:text-xs sm:tracking-[0.22em]">
                Артикул {product.article}
              </p>
              <Link
                className="line-clamp-2 block text-sm font-semibold leading-5 text-[var(--color-foreground)] sm:text-xl sm:leading-7"
                href={product.href}
              >
                {product.title}
              </Link>
          </div>

        </div>

        <div className="mt-auto flex flex-col gap-2 sm:gap-3">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between sm:gap-3">
            <div>
              <p className="text-sm font-semibold text-[var(--color-foreground)] sm:text-lg">
                {formatCurrency(product.priceText)}
              </p>
            </div>

            <span
              className={cn(
                "w-fit rounded-full px-2 py-1 text-[10px] font-semibold sm:px-3 sm:text-xs",
                isRequestOnly
                  ? "bg-[var(--color-accent-soft)] text-[var(--color-accent-strong)]"
                  : "bg-[var(--color-primary)]/12 text-[var(--color-primary-deep)]",
              )}
            >
              {product.availability}
            </span>
          </div>

          <div className="grid gap-2 sm:grid-cols-2 sm:items-center">
            <AddToCartButton className="w-full" compact productSlug={product.slug} />
            <Link
              className="inline-flex h-9 w-full items-center justify-center gap-1.5 rounded-full border border-[var(--color-primary)]/20 bg-white/75 px-2 text-xs font-semibold text-[var(--color-primary-deep)] transition hover:border-[var(--color-primary)]/50 sm:h-11 sm:gap-2 sm:px-4 sm:text-sm"
              href={product.href}
            >
              <ShoppingBag className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
              Подробнее
            </Link>
          </div>
        </div>
      </div>
    </article>
  );
}
