import { cn } from "@/lib/utils";

type RichTextProps = {
  html: string;
  className?: string;
};

export function RichText({ html, className }: RichTextProps) {
  return <div className={cn("rich-content", className)} dangerouslySetInnerHTML={{ __html: html }} />;
}
