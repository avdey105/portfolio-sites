"use client";

import { Search, SlidersHorizontal } from "lucide-react";
import { useDeferredValue, useState } from "react";

import type { CategoryRecord, ProductRecord } from "@/lib/site-data";
import { cn, hasNumericPrice } from "@/lib/utils";

import { ProductCard } from "./product-card";

type CatalogBrowserProps = {
  products: ProductRecord[];
  categories: CategoryRecord[];
  initialCategorySlug?: string;
  initialQuery?: string;
  title?: string;
  description?: string;
  showCategoryPicker?: boolean;
};

export function CatalogBrowser({
  products,
  categories,
  initialCategorySlug,
  initialQuery = "",
  title = "Каталог продуктов",
  description = "Подбирайте продукт по категории, названию или просто просматривайте всё, что сейчас есть в каталоге.",
  showCategoryPicker = true,
}: CatalogBrowserProps) {
  const [query, setQuery] = useState(initialQuery);
  const [categorySlug, setCategorySlug] = useState(initialCategorySlug ?? "all");
  const [sortBy, setSortBy] = useState("manual");
  const deferredQuery = useDeferredValue(query);

  let filteredProducts = products.filter((product) => {
    const inCategory = categorySlug === "all" || product.categorySlug === categorySlug;
    const searchTarget = `${product.title} ${product.summary} ${product.categoryNames.join(" ")}`.toLowerCase();
    const inQuery = deferredQuery.trim()
      ? searchTarget.includes(deferredQuery.trim().toLowerCase())
      : true;

    return inCategory && inQuery;
  });

  if (sortBy === "name") {
    filteredProducts = [...filteredProducts].sort((left, right) => left.title.localeCompare(right.title, "ru"));
  }

  if (sortBy === "price") {
    filteredProducts = [...filteredProducts].sort((left, right) => {
      const leftHasPrice = hasNumericPrice(left.priceText) ? 1 : 0;
      const rightHasPrice = hasNumericPrice(right.priceText) ? 1 : 0;
      return rightHasPrice - leftHasPrice || left.title.localeCompare(right.title, "ru");
    });
  }

  if (sortBy === "category") {
    filteredProducts = [...filteredProducts].sort((left, right) =>
      (left.categoryNames[0] ?? "").localeCompare(right.categoryNames[0] ?? "", "ru"),
    );
  }

  const resultHint = showCategoryPicker
    ? "Выбирайте категорию или используйте поиск, чтобы быстрее найти нужный товар."
    : "Используйте поиск, чтобы быстрее найти нужный товар в этом разделе.";

  return (
    <section className="space-y-6">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div className="max-w-2xl space-y-3">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[var(--color-primary-deep)]/70">Каталог</p>
          <h2 className="font-display text-3xl leading-tight text-[var(--color-foreground)] sm:text-4xl">{title}</h2>
          <p className="text-base leading-7 text-[var(--color-muted-foreground)]">{description}</p>
        </div>

        <div className="grid gap-3 sm:grid-cols-[1fr_auto] lg:min-w-[29rem]">
          <label className="relative block">
            <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--color-primary-deep)]/60" />
            <input
              className="h-12 w-full rounded-full border border-white/70 bg-white/80 pl-11 pr-4 text-sm outline-none transition focus:border-[var(--color-primary)]"
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Например, урбеч, сыр или пельмени"
              value={query}
            />
          </label>

          <label className="relative block">
            <SlidersHorizontal className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--color-primary-deep)]/60" />
            <select
              className="h-12 min-w-44 appearance-none rounded-full border border-white/70 bg-white/80 pl-11 pr-4 text-sm outline-none transition focus:border-[var(--color-primary)]"
              onChange={(event) => setSortBy(event.target.value)}
              value={sortBy}
            >
              <option value="manual">По умолчанию</option>
              <option value="name">По названию</option>
              <option value="price">Сначала с ценой</option>
              <option value="category">По категории</option>
            </select>
          </label>
        </div>
      </div>

      {showCategoryPicker ? (
        <div className="flex flex-wrap gap-3">
          <button
            className={cn(
              "rounded-full px-4 py-2 text-sm font-semibold transition",
              categorySlug === "all"
                ? "bg-[var(--color-primary)] text-white"
                : "border border-white/70 bg-white/72 text-[var(--color-primary-deep)] hover:border-[var(--color-primary)]/40",
            )}
            onClick={() => setCategorySlug("all")}
            type="button"
          >
            Все категории
          </button>

          {categories.map((category) => (
            <button
              className={cn(
                "rounded-full px-4 py-2 text-sm font-semibold transition",
                categorySlug === category.slug
                  ? "bg-[var(--color-primary)] text-white"
                  : "border border-white/70 bg-white/72 text-[var(--color-primary-deep)] hover:border-[var(--color-primary)]/40",
              )}
              key={category.slug}
              onClick={() => setCategorySlug(category.slug)}
              type="button"
            >
              {category.title}
            </button>
          ))}
        </div>
      ) : null}

      <div className="flex items-center justify-between gap-3 text-sm text-[var(--color-muted-foreground)]">
        <p>Найдено позиций: {filteredProducts.length}</p>
        <p>{resultHint}</p>
      </div>

      {filteredProducts.length ? (
        <div className="grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-2 xl:grid-cols-3">
          {filteredProducts.map((product) => (
            <ProductCard key={product.slug} product={product} />
          ))}
        </div>
      ) : (
        <div className="panel flex min-h-64 flex-col items-center justify-center gap-3 p-8 text-center">
          <h3 className="font-display text-2xl text-[var(--color-foreground)]">Ничего не найдено</h3>
          <p className="max-w-md text-sm leading-6 text-[var(--color-muted-foreground)]">
            Попробуйте изменить запрос или переключиться на другую категорию. Возможно, товар называется немного иначе.
          </p>
        </div>
      )}
    </section>
  );
}
