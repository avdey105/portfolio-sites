import { Mail, MapPin, Phone } from "lucide-react";
import Link from "next/link";

import { siteData } from "@/lib/site-data";

export function SiteFooter() {
  return (
    <footer className="page-shell pb-8 pt-10 sm:pb-10 sm:pt-14">
      <div className="panel overflow-hidden p-6 sm:p-8">
        <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr_1fr]">
          <div className="space-y-4">
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[var(--color-primary-deep)]/70">
              Дагестанские деликатесы
            </p>
            <h2 className="font-display text-3xl text-[var(--color-foreground)] sm:text-4xl">{siteData.brand.name}</h2>
            <p className="max-w-xl text-base leading-7 text-[var(--color-muted-foreground)]">
              Натуральные дагестанские продукты, традиционные рецептуры и удобный каталог для спокойного выбора любимых
              вкусов.
            </p>
          </div>

          <div className="space-y-4">
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-[var(--color-primary-deep)]">
              Навигация
            </p>
            <div className="grid gap-2">
              {[...siteData.navigation.top, ...siteData.navigation.categories].map((link) => (
                <Link
                  className="rounded-2xl bg-white/70 px-4 py-3 text-sm font-medium text-[var(--color-primary-deep)] transition hover:bg-white"
                  href={link.href}
                  key={`${link.href}-${link.label}`}
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-[var(--color-primary-deep)]">
              Контакты
            </p>
            <div className="space-y-3 text-sm leading-6 text-[var(--color-muted-foreground)]">
              <div className="flex gap-3 rounded-[24px] bg-white/70 p-4">
                <MapPin className="mt-1 h-4 w-4 shrink-0 text-[var(--color-primary-deep)]" />
                <span>{siteData.contact.address}</span>
              </div>
              <div className="flex gap-3 rounded-[24px] bg-white/70 p-4">
                <Phone className="mt-1 h-4 w-4 shrink-0 text-[var(--color-primary-deep)]" />
                <div className="space-y-1">
                  {siteData.contact.phones.map((phone) => (
                    <span className="block font-semibold text-[var(--color-primary-deep)]" key={phone}>
                      {phone}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex gap-3 rounded-[24px] bg-white/70 p-4">
                <Mail className="mt-1 h-4 w-4 shrink-0 text-[var(--color-primary-deep)]" />
                <div>
                  <span className="font-semibold text-[var(--color-primary-deep)]">
                    {siteData.contact.email}
                  </span>
                  <p>{siteData.contact.workingHours}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 border-t border-[var(--color-primary)]/10 pt-6 text-sm text-[var(--color-muted-foreground)]">
          Дагестанские деликатесы для дома, семьи и тёплых встреч за столом.
        </div>
      </div>
    </footer>
  );
}
