"use client";

import { Minus, Plus, Trash2 } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

import type { ProductRecord } from "@/lib/site-data";
import { cleanProductSummary, extractNumericPrice, formatCurrency, hasNumericPrice } from "@/lib/utils";
import { getCartItemsCount, useCartStore } from "@/store/cart-store";

type CartContentsProps = {
  products: ProductRecord[];
};

export function CartContents({ products }: CartContentsProps) {
  const items = useCartStore((state) => state.items);
  const addItem = useCartStore((state) => state.addItem);
  const decrementItem = useCartStore((state) => state.decrementItem);
  const removeItem = useCartStore((state) => state.removeItem);
  const clearCart = useCartStore((state) => state.clearCart);

  const cartItems = Object.entries(items)
    .map(([slug, quantity]) => ({
      product: products.find((item) => item.slug === slug),
      quantity,
    }))
    .filter((item): item is { product: ProductRecord; quantity: number } => Boolean(item.product));

  const total = cartItems.reduce((sum, item) => {
    const numericPrice = extractNumericPrice(item.product.priceText);
    return numericPrice ? sum + numericPrice * item.quantity : sum;
  }, 0);

  if (!cartItems.length) {
    return (
      <div className="panel flex min-h-80 flex-col items-center justify-center gap-4 p-8 text-center">
        <h2 className="font-display text-3xl text-[var(--color-foreground)]">Корзина пока пустая</h2>
        <p className="max-w-xl text-base leading-7 text-[var(--color-muted-foreground)]">
          Добавьте продукты, которые хотите уточнить или заказать, а затем отправьте заявку менеджеру.
        </p>
        <Link
          className="inline-flex h-12 items-center justify-center rounded-full bg-[var(--color-primary)] px-6 text-sm font-semibold text-white transition hover:bg-[var(--color-primary-deep)]"
          href="/shop/folder/urbech-dagestanskij"
        >
          Перейти к каталогу
        </Link>
      </div>
    );
  }

  return (
    <div className="grid gap-6 xl:grid-cols-[1.5fr_0.8fr]">
      <div className="space-y-4">
        {cartItems.map(({ product, quantity }) => (
          <article className="panel grid gap-4 p-4 sm:grid-cols-[8rem_1fr] sm:p-5" key={product.slug}>
            <div className="relative aspect-[4/4.4] overflow-hidden rounded-[24px] bg-white/80">
              {product.mainImage ? (
                <Image alt={product.title} className="object-cover" fill sizes="(max-width: 640px) 100vw, 128px" src={product.mainImage} />
              ) : null}
            </div>

            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div className="space-y-2">
                  <Link className="text-xl font-semibold text-[var(--color-foreground)]" href={product.href}>
                    {product.title}
                  </Link>
                  <p className="text-sm leading-6 text-[var(--color-muted-foreground)]">{cleanProductSummary(product.summary)}</p>
                  <p className="text-sm font-semibold text-[var(--color-primary-deep)]">{formatCurrency(product.priceText)}</p>
                </div>

                <button
                  className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/70 bg-white/80 text-[var(--color-muted-foreground)] transition hover:text-rose-600"
                  onClick={() => removeItem(product.slug)}
                  type="button"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="inline-flex items-center gap-2 rounded-full border border-white/70 bg-white/75 p-1">
                  <button
                    className="inline-flex h-9 w-9 items-center justify-center rounded-full text-[var(--color-primary-deep)] transition hover:bg-[var(--color-primary)]/10"
                    onClick={() => decrementItem(product.slug)}
                    type="button"
                  >
                    <Minus className="h-4 w-4" />
                  </button>
                  <span className="min-w-8 text-center text-sm font-semibold text-[var(--color-foreground)]">{quantity}</span>
                  <button
                    className="inline-flex h-9 w-9 items-center justify-center rounded-full text-[var(--color-primary-deep)] transition hover:bg-[var(--color-primary)]/10"
                    onClick={() => addItem(product.slug)}
                    type="button"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>

                <p className="text-sm font-semibold text-[var(--color-muted-foreground)]">
                  {hasNumericPrice(product.priceText)
                    ? `Подытог: ${new Intl.NumberFormat("ru-RU", {
                        style: "currency",
                        currency: "RUB",
                        maximumFractionDigits: 0,
                      }).format((extractNumericPrice(product.priceText) ?? 0) * quantity)}`
                    : "Цена и наличие уточняются вручную"}
                </p>
              </div>
            </div>
          </article>
        ))}
      </div>

      <aside className="panel h-fit p-5 sm:p-6">
        <div className="space-y-4">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[var(--color-primary-deep)]/70">
            Сводка
          </p>
          <h2 className="font-display text-3xl text-[var(--color-foreground)]">Ваша заявка</h2>
          <div className="space-y-3 rounded-[28px] bg-white/75 p-4 text-sm text-[var(--color-muted-foreground)]">
            <div className="flex items-center justify-between gap-4">
              <span>Позиций</span>
              <strong className="text-[var(--color-foreground)]">{getCartItemsCount(items)}</strong>
            </div>
            <div className="flex items-center justify-between gap-4">
              <span>С подтверждённой ценой</span>
              <strong className="text-[var(--color-foreground)]">
                {total
                  ? new Intl.NumberFormat("ru-RU", {
                      style: "currency",
                      currency: "RUB",
                      maximumFractionDigits: 0,
                    }).format(total)
                  : "По запросу"}
              </strong>
            </div>
          </div>
          <p className="text-sm leading-6 text-[var(--color-muted-foreground)]">
            Проверьте список товаров и оставьте контакты, чтобы менеджер уточнил наличие, итоговую сумму и доставку.
          </p>
          <button
            className="inline-flex h-11 items-center justify-center rounded-full border border-[var(--color-primary)]/20 bg-white/80 px-5 text-sm font-semibold text-[var(--color-primary-deep)] transition hover:border-[var(--color-primary)]/50"
            onClick={clearCart}
            type="button"
          >
            Очистить корзину
          </button>
        </div>
      </aside>
    </div>
  );
}
