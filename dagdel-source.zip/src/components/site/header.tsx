import { siteData } from "@/lib/site-data";

import { HeaderClient } from "./header-client";

export function SiteHeader() {
  return (
    <HeaderClient
      brandName={siteData.brand.name}
      categoryNavigation={siteData.navigation.categories}
      contact={siteData.contact}
      logoImage={siteData.brand.logoImage}
      slogan={siteData.brand.slogan}
      topNavigation={siteData.navigation.top}
    />
  );
}
