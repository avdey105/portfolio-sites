"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { CheckCircle2, SendHorizonal } from "lucide-react";
import { useTransition } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";

import { cn } from "@/lib/utils";

const leadSchema = z.object({
  name: z.string().min(2, "Укажите имя, чтобы мы знали, как к вам обращаться."),
  phone: z.string().min(10, "Нужен номер телефона для связи."),
  email: z
    .string()
    .trim()
    .optional()
    .or(z.literal(""))
    .refine((value) => !value || z.email().safeParse(value).success, "Проверьте формат e-mail."),
  message: z.string().min(8, "Добавьте пару слов о заказе или вопросе."),
});

type LeadFormValues = z.infer<typeof leadSchema>;

type LeadFormProps = {
  className?: string;
  compact?: boolean;
  heading?: string;
  description?: string;
};

export function LeadForm({
  className,
  compact = false,
  heading = "Оставить заявку",
  description = "В этой архивной версии форма проверяет поля на вашем устройстве и не отправляет заявку.",
}: LeadFormProps) {
  const [isPending, startTransition] = useTransition();

  const form = useForm<LeadFormValues>({
    resolver: zodResolver(leadSchema),
    defaultValues: {
      name: "",
      phone: "",
      email: "",
      message: "",
    },
  });

  const isSubmitted = form.formState.isSubmitSuccessful;

  function onSubmit() {
    startTransition(() => {
      form.reset();
    });
  }

  return (
    <div className={cn("panel self-start p-5 sm:p-6", className)}>
      <div className="mb-5 space-y-2">
        <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[var(--color-primary-deep)]/70">
          Обратная связь
        </p>
        <h3 className="font-display text-2xl text-[var(--color-foreground)] sm:text-3xl">{heading}</h3>
        <p className="max-w-xl text-sm leading-6 text-[var(--color-muted-foreground)]">{description}</p>
      </div>

      <form method="dialog" className="space-y-4" onSubmit={form.handleSubmit(onSubmit)}>
        <div className={cn("grid gap-4", compact ? "md:grid-cols-2" : "md:grid-cols-2")}>
          <label className="space-y-2 text-sm font-medium text-[var(--color-foreground)]">
            Имя
            <input
              {...form.register("name")}
              className="h-12 w-full rounded-2xl border border-white/70 bg-white/80 px-4 text-base outline-none transition focus:border-[var(--color-primary)]"
              placeholder="Как к вам обращаться"
            />
            {form.formState.errors.name ? (
              <span className="block text-xs text-rose-600">{form.formState.errors.name.message}</span>
            ) : null}
          </label>

          <label className="space-y-2 text-sm font-medium text-[var(--color-foreground)]">
            Телефон
            <input
              {...form.register("phone")}
              className="h-12 w-full rounded-2xl border border-white/70 bg-white/80 px-4 text-base outline-none transition focus:border-[var(--color-primary)]"
              placeholder="+7 (___) ___-__-__"
            />
            {form.formState.errors.phone ? (
              <span className="block text-xs text-rose-600">{form.formState.errors.phone.message}</span>
            ) : null}
          </label>
        </div>

        <label className="space-y-2 text-sm font-medium text-[var(--color-foreground)]">
          E-mail
          <input
            {...form.register("email")}
            className="h-12 w-full rounded-2xl border border-white/70 bg-white/80 px-4 text-base outline-none transition focus:border-[var(--color-primary)]"
            placeholder="Введите электронную почту"
          />
          {form.formState.errors.email ? (
            <span className="block text-xs text-rose-600">{form.formState.errors.email.message}</span>
          ) : null}
        </label>

        <label className="space-y-2 text-sm font-medium text-[var(--color-foreground)]">
          Сообщение
          <textarea
            {...form.register("message")}
            className={cn(
              "w-full rounded-[24px] border border-white/70 bg-white/80 px-4 py-3 text-base outline-none transition focus:border-[var(--color-primary)]",
              compact ? "min-h-24" : "min-h-28",
            )}
            placeholder="Что вы хотите заказать или уточнить?"
          />
          {form.formState.errors.message ? (
            <span className="block text-xs text-rose-600">{form.formState.errors.message.message}</span>
          ) : null}
        </label>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <button
            className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-[var(--color-primary)] px-6 text-sm font-semibold text-white transition hover:bg-[var(--color-primary-deep)] disabled:cursor-not-allowed disabled:opacity-60"
            disabled={isPending}
            type="submit"
          >
            {isSubmitted ? <CheckCircle2 className="h-4 w-4" /> : <SendHorizonal className="h-4 w-4" />}
            {isPending ? "Сохраняем..." : isSubmitted ? "Форма проверена. Заявка не отправлена" : "Проверить форму"}
          </button>
        </div>
      </form>
    </div>
  );
}
