import Image from "next/image";
import Link from "next/link";

type Breadcrumb = {
  label: string;
  href?: string;
};

type PageHeroProps = {
  eyebrow?: string;
  title: string;
  description: string;
  image?: string | null;
  breadcrumbs?: Breadcrumb[];
  actions?: React.ReactNode;
};

export function PageHero({ eyebrow, title, description, image, breadcrumbs = [], actions }: PageHeroProps) {
  const isLogoImage = image?.includes("logo");

  return (
    <section className="panel overflow-hidden p-4 sm:p-5">
      <div className="grid gap-5 lg:grid-cols-[1.05fr_0.95fr]">
        <div className="flex flex-col justify-between rounded-[30px] bg-[linear-gradient(180deg,rgba(18,127,112,0.1),rgba(255,255,255,0.6))] p-6 sm:p-8">
          <div className="space-y-5">
            {breadcrumbs.length ? (
              <div className="flex flex-wrap items-center gap-2 text-xs uppercase tracking-[0.18em] text-[var(--color-primary-deep)]/60">
                {breadcrumbs.map((breadcrumb, index) =>
                  breadcrumb.href ? (
                    <Link className="transition hover:text-[var(--color-primary)]" href={breadcrumb.href} key={`${breadcrumb.label}-${index}`}>
                      {breadcrumb.label}
                    </Link>
                  ) : (
                    <span key={`${breadcrumb.label}-${index}`}>{breadcrumb.label}</span>
                  ),
                )}
              </div>
            ) : null}

            <div className="space-y-4">
              {eyebrow ? (
                <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[var(--color-primary-deep)]/70">{eyebrow}</p>
              ) : null}
              <h1 className="font-display text-4xl leading-tight text-[var(--color-foreground)] sm:text-5xl">{title}</h1>
              <p className="max-w-2xl text-base leading-7 text-[var(--color-muted-foreground)] sm:text-lg">{description}</p>
            </div>
          </div>

          {actions ? <div className="mt-6">{actions}</div> : null}
        </div>

        <div className="relative min-h-72 overflow-hidden rounded-[30px] bg-white/75">
          {image ? (
            <Image
              alt={title}
              className={isLogoImage ? "object-contain p-6" : "object-cover"}
              fill
              priority
              sizes="(max-width: 1024px) 100vw, 45vw"
              src={image}
            />
          ) : null}
          {isLogoImage ? null : (
            <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(255,255,255,0),rgba(15,18,16,0.18))]" />
          )}
        </div>
      </div>
    </section>
  );
}
