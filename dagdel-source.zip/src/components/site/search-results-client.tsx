"use client";

import { useSearchParams } from "next/navigation";

import type { CategoryRecord, ProductRecord } from "@/lib/site-data";

import { CatalogBrowser } from "./catalog-browser";

type SearchResultsClientProps = {
  categories: CategoryRecord[];
  products: ProductRecord[];
};

export function SearchResultsClient({ categories, products }: SearchResultsClientProps) {
  const searchParams = useSearchParams();
  const query = searchParams.get("q") ?? "";

  return <CatalogBrowser categories={categories} initialQuery={query} products={products} />;
}
