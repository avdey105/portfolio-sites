"use client";

import useEmblaCarousel from "embla-carousel-react";
import { Leaf, MapPin, ShoppingBag } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { type PointerEvent, type TouchEvent, useEffect, useRef, useState } from "react";

import type { HeroSlide } from "@/lib/site-data";

type HeroSliderProps = {
  slides: HeroSlide[];
};

export function HeroSlider({ slides }: HeroSliderProps) {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true, align: "start" });
  const [selectedIndex, setSelectedIndex] = useState(0);
  const swipeStartRef = useRef<{ x: number; y: number; index: number } | null>(null);
  const hasMultipleSlides = slides.length > 1;

  function handlePointerDown(event: PointerEvent<HTMLDivElement>) {
    swipeStartRef.current = {
      x: event.clientX,
      y: event.clientY,
      index: emblaApi?.selectedScrollSnap() ?? selectedIndex,
    };
  }

  function finishSwipe(clientX: number, clientY: number) {
    const start = swipeStartRef.current;
    swipeStartRef.current = null;

    if (!start || !emblaApi || !hasMultipleSlides) {
      return;
    }

    const deltaX = clientX - start.x;
    const deltaY = clientY - start.y;
    const isHorizontalSwipe = Math.abs(deltaX) > 42 && Math.abs(deltaX) > Math.abs(deltaY) * 1.2;

    if (!isHorizontalSwipe) {
      return;
    }

    window.setTimeout(() => {
      if (emblaApi.selectedScrollSnap() !== start.index) {
        return;
      }

      if (deltaX < 0) {
        emblaApi.scrollNext();
      } else {
        emblaApi.scrollPrev();
      }
    }, 40);
  }

  function handlePointerUp(event: PointerEvent<HTMLDivElement>) {
    finishSwipe(event.clientX, event.clientY);
  }

  function handleTouchStart(event: TouchEvent<HTMLDivElement>) {
    const touch = event.touches[0];

    if (!touch) {
      return;
    }

    swipeStartRef.current = {
      x: touch.clientX,
      y: touch.clientY,
      index: emblaApi?.selectedScrollSnap() ?? selectedIndex,
    };
  }

  function handleTouchEnd(event: TouchEvent<HTMLDivElement>) {
    const touch = event.changedTouches[0];

    if (!touch) {
      swipeStartRef.current = null;
      return;
    }

    finishSwipe(touch.clientX, touch.clientY);
  }

  useEffect(() => {
    if (!emblaApi) {
      return undefined;
    }

    const onSelect = () => setSelectedIndex(emblaApi.selectedScrollSnap());
    onSelect();
    emblaApi.on("select", onSelect);

    const intervalId = hasMultipleSlides ? window.setInterval(() => emblaApi.scrollNext(), 5500) : undefined;

    return () => {
      emblaApi.off("select", onSelect);
      if (intervalId) {
        window.clearInterval(intervalId);
      }
    };
  }, [emblaApi, hasMultipleSlides]);

  return (
    <section className="space-y-4">
      <div className="ornament-band" />

      <div className="panel overflow-hidden p-3 sm:p-4 lg:p-5">
        <div className="space-y-5">
          <div className="overflow-hidden rounded-[32px] bg-[linear-gradient(180deg,rgba(217,111,39,0.08),rgba(255,255,255,0.42))] p-[3px]">
            <div
              className="relative overflow-hidden rounded-[29px] [touch-action:pan-y] active:cursor-grabbing"
              data-hero-carousel
              onPointerCancel={() => {
                swipeStartRef.current = null;
              }}
              onPointerDown={handlePointerDown}
              onPointerUp={handlePointerUp}
              onTouchEnd={handleTouchEnd}
              onTouchStart={handleTouchStart}
              ref={emblaRef}
            >
              <div className="flex">
                {slides.map((slide) => (
                  <div className="min-w-0 shrink-0 grow-0 basis-full" key={slide.image}>
                    <div className="relative aspect-[1600/376] overflow-hidden rounded-[29px] bg-[#f4ead4]">
                      <Image
                        alt={slide.alt}
                        className="select-none rounded-[29px] object-cover"
                        draggable={false}
                        fill
                        priority
                        sizes="(max-width: 1024px) 100vw, 80vw"
                        src={slide.image}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {hasMultipleSlides ? (
              <div className="mt-4 flex items-center justify-center gap-2 px-2">
                {slides.map((slide, index) => (
                <button
                  aria-current={selectedIndex === index ? "true" : undefined}
                  aria-label={`Перейти к слайду ${index + 1}`}
                  className={`h-2.5 rounded-full transition ${
                    selectedIndex === index ? "w-10 bg-[var(--color-primary)]" : "w-2.5 bg-[var(--color-primary)]/25"
                  }`}
                  key={slide.image}
                  onClick={() => emblaApi?.scrollTo(index)}
                  type="button"
                />
              ))}
              </div>
            ) : null}
          </div>

          <div className="rounded-[32px] bg-[linear-gradient(180deg,rgba(18,127,112,0.12),rgba(240,153,58,0.08))] p-6 sm:p-8">
            <div className="space-y-5">
              <div className="flex flex-wrap gap-2">
                <span className="inline-flex items-center gap-2 rounded-full bg-white/80 px-4 py-2 text-xs font-semibold uppercase tracking-[0.22em] text-[var(--color-primary-deep)]">
                  <Leaf className="h-3.5 w-3.5" />
                  Семейное производство
                </span>
                <span className="inline-flex items-center gap-2 rounded-full bg-white/80 px-4 py-2 text-xs font-semibold uppercase tracking-[0.22em] text-[var(--color-accent-strong)]">
                  <MapPin className="h-3.5 w-3.5" />
                  Доставка по Москве и области
                </span>
              </div>

              <div className="space-y-4">
                <p className="text-xs font-semibold uppercase tracking-[0.3em] text-[var(--color-primary-deep)]/70">
                  Дагестанские деликатесы
                </p>
                <h1 className="max-w-4xl font-display text-4xl leading-[1.02] text-[var(--color-foreground)] sm:text-5xl lg:text-[4.25rem]">
                  Урбеч, пироги, сыры и пельмени с доставкой по Москве и области.
                </h1>
                <p className="max-w-3xl text-base leading-7 text-[var(--color-muted-foreground)] sm:text-lg">
                  Натуральные дагестанские продукты, традиционные рецепты и удобный каталог, в котором легко выбрать
                  любимые вкусы для дома, семьи и подарка.
                </p>
              </div>
            </div>

            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-[var(--color-primary)] px-6 text-sm font-semibold text-white transition hover:bg-[var(--color-primary-deep)]"
                href="/shop/folder/urbech-dagestanskij"
              >
                <ShoppingBag className="h-4 w-4" />
                Открыть каталог
              </Link>
              <Link
                className="inline-flex h-12 items-center justify-center rounded-full border border-[var(--color-primary)]/20 bg-white/80 px-6 text-sm font-semibold text-[var(--color-primary-deep)] transition hover:border-[var(--color-primary)]/50"
                href="/kontakty"
              >
                Связаться с нами
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
