"use client";

import { MapPin, Menu, Phone, Search, ShoppingBag, UserRound, X } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

import type { ContactInfo, SiteLink } from "@/lib/site-data";
import { cn } from "@/lib/utils";
import { getCartItemsCount, useCartStore } from "@/store/cart-store";

type HeaderClientProps = {
  brandName: string;
  slogan: string;
  logoImage: string | null;
  topNavigation: SiteLink[];
  categoryNavigation: SiteLink[];
  contact: ContactInfo;
};

function isLinkActive(pathname: string, href: string) {
  if (href === "/") {
    return pathname === "/";
  }

  return pathname === href || pathname.startsWith(`${href}/`);
}

export function HeaderClient({
  brandName,
  slogan,
  logoImage,
  topNavigation,
  categoryNavigation,
  contact,
}: HeaderClientProps) {
  const pathname = usePathname();
  const items = useCartStore((state) => state.items);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const cartCount = getCartItemsCount(items);

  return (
    <>
      <div className="hidden border-b border-[var(--color-primary)]/12 bg-[var(--color-primary-soft)]/85 lg:block">
        <div className="page-shell flex items-center justify-between gap-6 py-3">
          <nav className="flex flex-wrap items-center gap-5 text-sm text-[var(--color-primary-deep)]">
            {topNavigation.map((link) => (
              <Link
                className={cn(
                  "transition hover:text-[var(--color-primary)]",
                  isLinkActive(pathname, link.href) && "font-semibold text-[var(--color-primary)]",
                )}
                href={link.href}
                key={link.href}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-5 text-sm text-[var(--color-primary-deep)]">
            <span className="font-semibold">
              {contact.phones[0]}
            </span>
            <p>{contact.workingHours}</p>
          </div>
        </div>
      </div>

      <header className="page-shell pt-4 sm:pt-5">
        <div className="panel overflow-hidden">
          <div className="flex items-center justify-between px-4 py-4 lg:hidden">
            <Link className="flex min-w-0 flex-1 items-center gap-3 pr-3" href="/">
              <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-full border border-white/70 bg-white/80">
                {logoImage ? <Image alt={brandName} className="object-cover" fill sizes="56px" src={logoImage} /> : null}
              </div>
              <div className="min-w-0 space-y-1">
                <p className="font-display text-lg leading-5 text-[var(--color-foreground)] sm:text-xl">{brandName}</p>
                <p className="text-xs leading-4 text-[var(--color-muted-foreground)]">{slogan}</p>
              </div>
            </Link>

            <div className="flex shrink-0 items-center gap-2">
              <Link
                className="relative inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/70 bg-white/80 text-[var(--color-primary-deep)]"
                href="/shop/cart"
              >
                <ShoppingBag className="h-5 w-5" />
                <span className="absolute -right-1 -top-1 inline-flex min-h-5 min-w-5 items-center justify-center rounded-full bg-[var(--color-accent)] px-1 text-[11px] font-bold text-white">
                  {cartCount}
                </span>
              </Link>
            </div>
          </div>

          <div className="hidden gap-6 px-6 py-6 lg:grid lg:grid-cols-[1fr_auto_1fr] lg:items-center">
            <div className="space-y-3">
              <div className="inline-flex items-center gap-3 rounded-full bg-white/82 px-4 py-2 text-sm text-[var(--color-primary-deep)]">
                <MapPin className="h-4 w-4" />
                <span>{contact.address}</span>
              </div>
              <div className="inline-flex items-center gap-3 rounded-full bg-white/82 px-4 py-2 text-sm text-[var(--color-primary-deep)]">
                <Phone className="h-4 w-4" />
                <span className="font-semibold">
                  {contact.phones[0]}
                </span>
              </div>
            </div>

            <Link className="flex items-center gap-5 justify-self-center" href="/">
              <div className="relative h-28 w-28 overflow-hidden rounded-full border border-[var(--color-accent)]/30 bg-white/80 p-2 shadow-[0_20px_50px_rgba(214,111,26,0.12)]">
                {logoImage ? <Image alt={brandName} className="object-cover" fill sizes="112px" src={logoImage} /> : null}
              </div>
              <div className="max-w-72 space-y-2">
                <p className="font-display text-3xl leading-none text-[var(--color-foreground)]">{brandName}</p>
                <p className="text-base leading-6 text-[var(--color-muted-foreground)]">{slogan}</p>
              </div>
            </Link>

            <div className="justify-self-end">
              <div className="flex items-center justify-end gap-3">
                <Link
                  className="inline-flex h-12 items-center justify-center gap-2 rounded-full border border-white/70 bg-white/82 px-5 text-sm font-semibold text-[var(--color-primary-deep)] transition hover:border-[var(--color-primary)]/40"
                  href="/cabinet"
                >
                  <UserRound className="h-4 w-4" />
                  Кабинет
                </Link>

                <Link
                  className="relative inline-flex h-12 items-center justify-center gap-2 rounded-full bg-[var(--color-accent)] px-5 text-sm font-semibold text-white transition hover:bg-[var(--color-accent-strong)]"
                  href="/shop/cart"
                >
                  <ShoppingBag className="h-4 w-4" />
                  Корзина
                  <span className="inline-flex min-h-6 min-w-6 items-center justify-center rounded-full bg-white/20 px-1 text-xs font-bold">
                    {cartCount}
                  </span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="page-shell relative z-30 pb-4 pt-3">
        <div className="rounded-[2rem] border border-white/80 bg-[var(--color-surface)]/95 px-3 py-3 shadow-[0_18px_50px_rgba(35,43,40,0.08),inset_0_1px_0_rgba(255,255,255,0.7)] sm:px-4 lg:px-6">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div className="no-scrollbar flex items-center gap-2 overflow-x-auto pb-1">
              <button
                aria-expanded={isMenuOpen}
                aria-label="Открыть меню"
                className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-white/70 bg-white/82 text-[var(--color-primary-deep)] transition hover:border-[var(--color-primary)]/40 lg:hidden [touch-action:manipulation]"
                data-mobile-menu-button
                onClick={(event) => {
                  event.preventDefault();
                  setIsMenuOpen(true);
                }}
                onTouchEnd={(event) => {
                  event.preventDefault();
                  setIsMenuOpen(true);
                }}
                type="button"
              >
                <Menu className="h-5 w-5" />
              </button>

              {categoryNavigation.map((link) => (
                <Link
                  className={cn(
                    "whitespace-nowrap rounded-full border px-4 py-2 text-sm font-semibold transition",
                    isLinkActive(pathname, link.href)
                      ? "border-[var(--color-primary)] bg-[var(--color-primary)] text-white"
                      : "border-white/70 bg-white/78 text-[var(--color-primary-deep)] hover:border-[var(--color-primary)]/40",
                  )}
                  href={link.href}
                  key={link.href}
                >
                  {link.label}
                </Link>
              ))}
            </div>

            <form
              action="/portfolio-sites/urbech/search/"
              className="relative min-w-0 lg:w-[22rem]"
              data-header-search
            >
              <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--color-primary-deep)]/60" />
              <input
                className="h-11 w-full rounded-full border border-white/70 bg-white/88 pl-11 pr-4 text-sm outline-none transition focus:border-[var(--color-primary)]"
                name="q"
                placeholder="Найти товар"
              />
            </form>
          </div>
        </div>
      </div>

      {isMenuOpen ? (
        <div
          className="fixed inset-0 z-50 bg-[rgba(22,24,21,0.45)] px-4 py-5 lg:hidden"
          data-mobile-menu-overlay
          onClick={() => setIsMenuOpen(false)}
        >
          <div
            className="panel ml-auto flex h-full max-w-sm flex-col overflow-hidden"
            onClick={(event) => event.stopPropagation()}
          >
              <div className="flex items-center justify-between border-b border-[var(--color-primary)]/10 px-5 py-4">
                <p className="font-display text-2xl text-[var(--color-foreground)]">Меню</p>
                <button
                  aria-label="Закрыть меню"
                  className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/70 bg-white/80 text-[var(--color-primary-deep)]"
                  onClick={() => setIsMenuOpen(false)}
                  type="button"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="flex-1 space-y-6 overflow-y-auto px-5 py-5">
                <div className="space-y-2">
                  <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[var(--color-primary-deep)]/70">
                    Страницы
                  </p>
                  {topNavigation.map((link) => (
                    <Link
                      className={cn(
                        "block rounded-2xl px-4 py-3 text-base font-medium transition",
                        isLinkActive(pathname, link.href)
                          ? "bg-[var(--color-primary)] text-white"
                          : "bg-white/80 text-[var(--color-primary-deep)]",
                      )}
                      href={link.href}
                      key={link.href}
                      onClick={() => setIsMenuOpen(false)}
                    >
                      {link.label}
                    </Link>
                  ))}
                </div>

                <div className="space-y-2">
                  <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[var(--color-primary-deep)]/70">
                    Категории
                  </p>
                  {categoryNavigation.map((link) => (
                    <Link
                      className={cn(
                        "block rounded-2xl px-4 py-3 text-base font-medium transition",
                        isLinkActive(pathname, link.href)
                          ? "bg-[var(--color-primary)] text-white"
                          : "bg-white/80 text-[var(--color-primary-deep)]",
                      )}
                      href={link.href}
                      key={link.href}
                      onClick={() => setIsMenuOpen(false)}
                    >
                      {link.label}
                    </Link>
                  ))}
                </div>

                <div className="space-y-3 rounded-[28px] bg-white/80 p-4 text-sm leading-6 text-[var(--color-primary-deep)]">
                  <p className="font-semibold">{contact.address}</p>
                  <span className="block font-semibold">
                    {contact.phones[0]}
                  </span>
                  <p>{contact.workingHours}</p>
                </div>
              </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
