"use client";

import Image from "next/image";
import { useState } from "react";

import { cn } from "@/lib/utils";

type ProductGalleryProps = {
  images: string[];
  title: string;
};

export function ProductGallery({ images, title }: ProductGalleryProps) {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const currentImage = images[selectedIndex] ?? images[0] ?? null;

  if (!currentImage) {
    return (
      <div className="panel flex min-h-80 items-center justify-center p-8 text-center text-sm text-[var(--color-muted-foreground)]">
        Фотографии товара скоро появятся.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="panel overflow-hidden p-3">
        <div className="relative aspect-[4/4.4] overflow-hidden rounded-[28px] bg-white/70">
          <Image
            alt={title}
            className="object-cover"
            fill
            key={currentImage}
            priority
            sizes="(max-width: 1024px) 100vw, 45vw"
            src={currentImage}
          />
        </div>
      </div>

      {images.length > 1 ? (
        <div className="grid grid-cols-4 gap-3">
          {images.map((image, index) => (
            <button
              className={cn(
                "relative aspect-square overflow-hidden rounded-[22px] border bg-white/70 p-1 transition",
                index === selectedIndex
                  ? "border-[var(--color-primary)] shadow-[0_12px_30px_rgba(18,127,112,0.18)]"
                  : "border-white/70 hover:border-[var(--color-primary)]/40",
              )}
              key={image}
              onClick={() => setSelectedIndex(index)}
              type="button"
            >
              <Image alt={`${title} ${index + 1}`} className="object-cover" fill sizes="25vw" src={image} />
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}
