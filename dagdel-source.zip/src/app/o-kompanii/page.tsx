import type { Metadata } from "next";

import { LeadForm } from "@/components/site/lead-form";
import { PageHero } from "@/components/site/page-hero";
import { RichText } from "@/components/site/rich-text";
import { getInfoPageBySlug, siteData } from "@/lib/site-data";
import { cleanLegacyContentHtml } from "@/lib/utils";

const page = getInfoPageBySlug("o-kompanii");

export const metadata: Metadata = {
  title: page?.title ?? "О компании",
  description: page?.excerpt ?? siteData.brand.description,
};

export default function AboutPage() {
  const cleanBodyHtml = page ? cleanLegacyContentHtml(page.bodyHtml) : "";

  return (
    <div className="space-y-8 pb-10 pt-2">
      <div className="page-shell">
        <PageHero
          actions={
            <div className="flex flex-wrap gap-3">
              <span className="inline-flex rounded-full bg-white/80 px-4 py-2 text-sm font-semibold text-[var(--color-primary-deep)]">
                С 1992 года
              </span>
              <span className="inline-flex rounded-full bg-white/80 px-4 py-2 text-sm font-semibold text-[var(--color-primary-deep)]">
                Традиционные рецепты
              </span>
            </div>
          }
          breadcrumbs={[
            { label: "Главная", href: "/" },
            { label: "О компании" },
          ]}
          description={page?.excerpt ?? "История производства, подход к качеству и философия натурального продукта."}
          eyebrow="О компании"
          image={siteData.brand.logoImage}
          title={page?.title ?? "О компании"}
        />
      </div>

      <div className="page-shell grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <article className="panel p-6 sm:p-8">
          {cleanBodyHtml ? <RichText html={cleanBodyHtml} /> : null}
        </article>
        <LeadForm compact description="Если вы хотите задать вопрос по ассортименту, срокам или доставке, оставьте контакты, и мы свяжемся с вами." />
      </div>
    </div>
  );
}
