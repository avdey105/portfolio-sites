import type { Metadata } from "next";
import { Mail, MapPinned, Phone } from "lucide-react";

import { LeadForm } from "@/components/site/lead-form";
import { PageHero } from "@/components/site/page-hero";
import { getInfoPageBySlug, siteData } from "@/lib/site-data";
import { createPhoneHref } from "@/lib/utils";

const page = getInfoPageBySlug("kontakty");

export const metadata: Metadata = {
  title: page?.title ?? "Контакты",
  description: page?.excerpt ?? siteData.brand.description,
};

export default function ContactsPage() {
  const contacts = page?.contacts ?? siteData.contact;

  return (
    <div className="space-y-8 pb-10 pt-2">
      <div className="page-shell">
        <PageHero
          actions={
            <div className="flex flex-wrap gap-3">
              {contacts.phones.map((phone) => (
                <a
                  className="inline-flex rounded-full bg-white/82 px-4 py-2 text-sm font-semibold text-[var(--color-primary-deep)]"
                  href={createPhoneHref(phone)}
                  key={phone}
                >
                  {phone}
                </a>
              ))}
            </div>
          }
          breadcrumbs={[
            { label: "Главная", href: "/" },
            { label: "Контакты" },
          ]}
          description={`${contacts.phones.join(" • ")} • ${contacts.workingHours}. ${contacts.address}`}
          eyebrow="Контакты"
          image={siteData.heroSlides[0]?.image ?? siteData.brand.logoImage}
          title={page?.title ?? "Контакты"}
        />
      </div>

      <div className="page-shell grid gap-6 lg:grid-cols-[1fr_0.9fr]">
        <article className="panel p-6 sm:p-8">
          <div className="space-y-6">
            <div className="space-y-3">
              <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[var(--color-primary-deep)]/70">
                Контактная информация
              </p>
              <h2 className="font-display text-3xl text-[var(--color-foreground)] sm:text-4xl">Связаться с нами</h2>
              <p className="text-base leading-7 text-[var(--color-muted-foreground)]">
                Позвоните, напишите в WhatsApp или Telegram, либо оставьте заявку в форме рядом.
              </p>
            </div>

            <div className="grid gap-3 text-sm leading-6 text-[var(--color-muted-foreground)]">
              <p>
                <strong className="text-[var(--color-foreground)]">Телефон / WhatsApp / Telegram: </strong>
                <a className="font-semibold text-[var(--color-primary-deep)]" href={createPhoneHref(contacts.phones[0] ?? "")}>
                  {contacts.phones[0]}
                </a>
              </p>
              <p>
                <strong className="text-[var(--color-foreground)]">График работы: </strong>
                {contacts.workingHours}
              </p>
              <p>
                <strong className="text-[var(--color-foreground)]">Адрес: </strong>
                {contacts.address}
              </p>
              <p>
                <strong className="text-[var(--color-foreground)]">Email: </strong>
                <a className="font-semibold text-[var(--color-primary-deep)]" href={`mailto:${contacts.email}`}>
                  {contacts.email}
                </a>
              </p>
            </div>

            <div className="rounded-[28px] bg-white/72 p-5 text-sm leading-7 text-[var(--color-muted-foreground)]">
              <p className="font-semibold text-[var(--color-foreground)]">Реквизиты</p>
              <p>ООО «ИИК «Квадра-НТ»</p>
              <p>ОГРН 1107746348720, ИНН 7709852865, КПП 772001001</p>
              <p>Генеральный директор: Ахмедов Гаджи-Умар Сайпулаевич</p>
            </div>
          </div>

          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            <div className="rounded-[28px] bg-white/75 p-4">
              <Phone className="h-5 w-5 text-[var(--color-primary-deep)]" />
              <div className="mt-3 space-y-1 text-sm leading-6 text-[var(--color-muted-foreground)]">
                {contacts.phones.map((phone) => (
                  <a className="block font-semibold text-[var(--color-primary-deep)]" href={createPhoneHref(phone)} key={phone}>
                    {phone}
                  </a>
                ))}
              </div>
            </div>
            <div className="rounded-[28px] bg-white/75 p-4">
              <Mail className="h-5 w-5 text-[var(--color-primary-deep)]" />
              <div className="mt-3 text-sm leading-6 text-[var(--color-muted-foreground)]">
                <a className="font-semibold text-[var(--color-primary-deep)]" href={`mailto:${contacts.email}`}>
                  {contacts.email}
                </a>
                <p>{contacts.workingHours}</p>
              </div>
            </div>
            <div className="rounded-[28px] bg-white/75 p-4">
              <MapPinned className="h-5 w-5 text-[var(--color-primary-deep)]" />
              <div className="mt-3 text-sm leading-6 text-[var(--color-muted-foreground)]">
                <p className="font-semibold text-[var(--color-primary-deep)]">Адрес</p>
                <p>{contacts.address}</p>
              </div>
            </div>
          </div>
        </article>

        <LeadForm compact description="Оставьте контакты и сообщение, и мы свяжемся с вами удобным способом." />
      </div>
    </div>
  );
}
