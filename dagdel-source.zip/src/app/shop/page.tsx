import { redirect } from "next/navigation";

export default function ShopIndexPage() {
  redirect("/shop/folder/urbech-dagestanskij");
}
