import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";

import { AddToCartButton } from "@/components/site/add-to-cart-button";
import { LeadForm } from "@/components/site/lead-form";
import { ProductGallery } from "@/components/site/product-gallery";
import { ProductCard } from "@/components/site/product-card";
import { RichText } from "@/components/site/rich-text";
import { getCategoryBySlug, getProductBySlug, getRelatedProducts, products, siteData } from "@/lib/site-data";
import { cleanProductSummary, extractProductDescriptionHtml, formatCurrency } from "@/lib/utils";

export function generateStaticParams() {
  return products.map((product) => ({ slug: product.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const product = getProductBySlug(slug);

  return {
    title: product?.title ?? "Товар",
    description: product?.summary ?? siteData.brand.description,
  };
}

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const product = getProductBySlug(slug);

  if (!product) {
    notFound();
  }

  const category = getCategoryBySlug(product.categorySlug);
  const relatedProducts = getRelatedProducts(product);
  const summary = cleanProductSummary(product.summary);
  const descriptionHtml = extractProductDescriptionHtml(product.descriptionHtml);
  const additionalImages = product.gallery.slice(1);

  return (
    <div className="space-y-8 pb-10 pt-4">
      <div className="page-shell flex flex-wrap gap-2 text-xs uppercase tracking-[0.18em] text-[var(--color-primary-deep)]/65">
        <Link href="/">Главная</Link>
        <span>/</span>
        {category ? <Link href={category.href}>{category.title}</Link> : null}
        <span>/</span>
        <span>{product.title}</span>
      </div>

      <div className="page-shell grid gap-6 lg:grid-cols-[0.92fr_1.08fr]">
        <ProductGallery images={product.gallery} title={product.title} />

        <section className="panel p-6 sm:p-8">
          <div className="space-y-6">
            <div className="space-y-4">
              <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[var(--color-primary-deep)]/70">
                {category?.title ?? "Каталог"}
              </p>
              <h1 className="font-display text-4xl leading-tight text-[var(--color-foreground)] sm:text-5xl">{product.title}</h1>
              <p className="text-base leading-7 text-[var(--color-muted-foreground)]">{summary}</p>
            </div>

            <div className="grid gap-4 sm:grid-cols-3">
              <div className="rounded-[26px] bg-white/75 p-4">
                <p className="text-xs uppercase tracking-[0.18em] text-[var(--color-muted-foreground)]">Цена</p>
                <p className="mt-2 text-lg font-semibold text-[var(--color-foreground)]">{formatCurrency(product.priceText)}</p>
              </div>
              <div className="rounded-[26px] bg-white/75 p-4">
                <p className="text-xs uppercase tracking-[0.18em] text-[var(--color-muted-foreground)]">Наличие</p>
                <p className="mt-2 text-lg font-semibold text-[var(--color-foreground)]">{product.availability}</p>
              </div>
              <div className="rounded-[26px] bg-white/75 p-4">
                <p className="text-xs uppercase tracking-[0.18em] text-[var(--color-muted-foreground)]">Артикул</p>
                <p className="mt-2 text-lg font-semibold text-[var(--color-foreground)]">{product.article}</p>
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              <AddToCartButton productSlug={product.slug} />
              {category ? (
                <Link
                  className="inline-flex h-11 items-center justify-center rounded-full border border-[var(--color-primary)]/20 bg-white/78 px-5 text-sm font-semibold text-[var(--color-primary-deep)] transition hover:border-[var(--color-primary)]/50"
                  href={category.href}
                >
                  Назад в раздел
                </Link>
              ) : null}
            </div>
          </div>
        </section>
      </div>

      <div className="page-shell grid gap-6 lg:grid-cols-[1.05fr_0.95fr]">
        <section className="panel p-6 sm:p-8">
          <h2 className="font-display text-3xl text-[var(--color-foreground)] sm:text-4xl">Описание</h2>
          <div className="mt-5">{descriptionHtml ? <RichText html={descriptionHtml} /> : null}</div>
        </section>
        <LeadForm compact description="Оставьте контакты, и мы свяжемся с вами по наличию, срокам и удобному способу получения." />
      </div>

      {additionalImages.length ? (
        <section className="page-shell space-y-5">
          <div className="space-y-3">
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[var(--color-primary-deep)]/70">
              Фото товара
            </p>
            <h2 className="font-display text-3xl text-[var(--color-foreground)] sm:text-4xl">Дополнительные фото</h2>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {additionalImages.map((image, index) => (
              <div className="panel overflow-hidden p-2" key={image}>
                <div className="relative aspect-[4/3] overflow-hidden rounded-[26px] bg-white/75">
                  <Image
                    alt={`${product.title}: фото ${index + 2}`}
                    className="object-cover"
                    fill
                    sizes="(max-width: 768px) 100vw, 33vw"
                    src={image}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      {relatedProducts.length ? (
        <section className="page-shell space-y-5">
          <div className="flex items-end justify-between gap-4">
            <div className="space-y-3">
              <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[var(--color-primary-deep)]/70">
                Рядом по каталогу
              </p>
              <h2 className="font-display text-3xl text-[var(--color-foreground)] sm:text-4xl">Похожие позиции</h2>
            </div>
          </div>
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
            {relatedProducts.map((relatedProduct) => (
              <ProductCard key={relatedProduct.slug} product={relatedProduct} />
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}
