import type { Metadata } from "next";
import { notFound } from "next/navigation";

import { CatalogBrowser } from "@/components/site/catalog-browser";
import { PageHero } from "@/components/site/page-hero";
import { categories, getCategoryBySlug, getProductsByCategorySlug, siteData } from "@/lib/site-data";

export function generateStaticParams() {
  return categories.map((category) => ({ slug: category.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const category = getCategoryBySlug(slug);

  return {
    title: category?.title ?? "Категория",
    description: category?.excerpt ?? siteData.brand.description,
  };
}

export default async function CategoryPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const category = getCategoryBySlug(slug);

  if (!category) {
    notFound();
  }

  const categoryProducts = getProductsByCategorySlug(category.slug);

  return (
    <div className="space-y-8 pb-10 pt-2">
      <div className="page-shell">
        <PageHero
          breadcrumbs={[
            { label: "Главная", href: "/" },
            { label: "Каталог", href: "/shop/folder/urbech-dagestanskij" },
            { label: category.title },
          ]}
          description={category.excerpt}
          eyebrow="Категория"
          image={category.heroImage}
          title={category.title}
        />
      </div>

      <div className="page-shell">
        <CatalogBrowser
          categories={categories}
          description={`В разделе «${category.title}» собраны все актуальные позиции категории с удобным поиском и понятной навигацией.`}
          initialCategorySlug={category.slug}
          key={category.slug}
          products={categoryProducts}
          showCategoryPicker={false}
          title={category.title}
        />
      </div>
    </div>
  );
}
