import { redirect } from "next/navigation";

export default function ShopFolderIndexPage() {
  redirect("/shop/folder/urbech-dagestanskij");
}
