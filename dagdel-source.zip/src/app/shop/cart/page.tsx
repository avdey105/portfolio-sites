import type { Metadata } from "next";

import { CartContents } from "@/components/site/cart-contents";
import { LeadForm } from "@/components/site/lead-form";
import { PageHero } from "@/components/site/page-hero";
import { products, siteData } from "@/lib/site-data";

export const metadata: Metadata = {
  title: "Корзина",
  description: siteData.brand.description,
};

export default function CartPage() {
  return (
    <div className="space-y-8 pb-10 pt-2">
      <div className="page-shell">
        <PageHero
          breadcrumbs={[
            { label: "Главная", href: "/" },
            { label: "Корзина" },
          ]}
          description="Соберите интересующие товары в корзине и отправьте заявку, чтобы менеджер уточнил наличие, итоговую сумму и доставку."
          eyebrow="Корзина и заявки"
          image={products[0]?.mainImage ?? siteData.brand.logoImage}
          title="Корзина"
        />
      </div>

      <div className="page-shell">
        <CartContents products={products} />
      </div>

      <div className="page-shell">
        <LeadForm
          compact
          description="Если вы уже собрали позиции в корзине, оставьте контакты здесь, и мы свяжемся с вами по составу заказа."
          heading="Отправить заявку по корзине"
        />
      </div>
    </div>
  );
}
