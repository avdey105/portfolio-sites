import Image from "next/image";
import Link from "next/link";

import { CatalogBrowser } from "@/components/site/catalog-browser";
import { HeroSlider } from "@/components/site/hero-slider";
import { LeadForm } from "@/components/site/lead-form";
import { categories, products, siteData } from "@/lib/site-data";

export default function Home() {
  return (
    <div className="space-y-8 pb-10 pt-2 sm:space-y-10 sm:pb-12">
      <div className="page-shell">
        <HeroSlider slides={siteData.heroSlides} />
      </div>

      <section className="page-shell grid gap-4 md:grid-cols-3">
        {[
          {
            title: "Натуральное сырьё",
            text: "Только семена, орехи и традиционные рецептуры без лишних добавок.",
          },
          {
            title: "Удобный каталог",
            text: "Товары легко найти по категориям, поиску и понятным карточкам и на компьютере, и на телефоне.",
          },
          {
            title: "Любимые категории",
            text: "В одном месте собраны урбеч, пироги, сыры и пельмени для дома, семьи и уютных застолий.",
          },
        ].map((item) => (
          <article className="panel p-5 sm:p-6" key={item.title}>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[var(--color-primary-deep)]/70">
              Почему это лучше
            </p>
            <h2 className="mt-3 font-display text-3xl text-[var(--color-foreground)]">{item.title}</h2>
            <p className="mt-3 text-sm leading-7 text-[var(--color-muted-foreground)]">{item.text}</p>
          </article>
        ))}
      </section>

      <section className="page-shell grid gap-5 lg:grid-cols-4">
        {categories.map((category) => (
          <Link className="panel group overflow-hidden p-3" href={category.href} key={category.slug}>
            <div className="relative aspect-[4/3] overflow-hidden rounded-[26px] bg-white/75">
              {category.heroImage ? (
                <Image
                  alt={category.title}
                  className="object-cover transition duration-500 group-hover:scale-[1.04]"
                  fill
                  sizes="(max-width: 1024px) 100vw, 25vw"
                  src={category.heroImage}
                />
              ) : null}
            </div>
            <div className="space-y-3 px-2 pb-2 pt-5">
              <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[var(--color-primary-deep)]/70">
                {category.products.length} позиций
              </p>
              <h2 className="font-display text-3xl text-[var(--color-foreground)]">{category.title}</h2>
              <p className="text-sm leading-7 text-[var(--color-muted-foreground)]">{category.excerpt}</p>
            </div>
          </Link>
        ))}
      </section>

      <section className="page-shell">
        <CatalogBrowser
          categories={categories}
          description="Выбирайте продукты по категориям, ищите по названию и быстро переходите к нужным позициям."
          initialCategorySlug={categories[0]?.slug}
          products={products}
          title="Каталог продукции"
        />
      </section>

      <section className="page-shell grid gap-6 lg:grid-cols-[1.05fr_0.95fr]">
        <article className="panel overflow-hidden p-6 sm:p-8">
          <div className="space-y-4">
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[var(--color-primary-deep)]/70">
              Почему выбирают нас
            </p>
            <h2 className="font-display text-4xl text-[var(--color-foreground)]">Традиционный вкус и аккуратная подача.</h2>
            <p className="text-base leading-7 text-[var(--color-muted-foreground)]">
              Мы делаем ставку на натуральные составы, понятный ассортимент и удобный выбор продуктов, которые приятно
              заказать для себя, семьи или в подарок.
            </p>
          </div>

          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {[
              "Натуральные составы и традиционные рецептуры",
              "Удобная навигация по категориям и карточкам товаров",
              "Комфортный просмотр на телефонах, планшетах и компьютерах",
              "Понятная подача ассортимента для быстрого выбора",
            ].map((item) => (
              <div className="rounded-[26px] bg-white/75 p-4 text-sm leading-6 text-[var(--color-primary-deep)]" key={item}>
                {item}
              </div>
            ))}
          </div>
        </article>

        <LeadForm />
      </section>
    </div>
  );
}
