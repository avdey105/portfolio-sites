import type { Metadata } from "next";
import { ShieldCheck, Sparkles, UserRound } from "lucide-react";

import { LeadForm } from "@/components/site/lead-form";
import { PageHero } from "@/components/site/page-hero";
import { siteData } from "@/lib/site-data";

export const metadata: Metadata = {
  title: "Кабинет",
  description: siteData.brand.description,
};

export default function CabinetPage() {
  return (
    <div className="space-y-8 pb-10 pt-2">
      <div className="page-shell">
        <PageHero
          breadcrumbs={[
            { label: "Главная", href: "/" },
            { label: "Кабинет" },
          ]}
          description="Здесь можно оставить запрос по повторному заказу, доставке или уточнению наличия."
          eyebrow="Личный кабинет"
          image={siteData.brand.logoImage}
          title="Кабинет клиента"
        />
      </div>

      <div className="page-shell grid gap-6 lg:grid-cols-[1fr_0.9fr]">
        <section className="space-y-4">
          {[
            {
              icon: UserRound,
              title: "Повторный заказ",
              text: "Если вы уже покупали у нас продукты, оставьте контакт, и менеджер поможет быстро повторить заказ.",
            },
            {
              icon: ShieldCheck,
              title: "Доставка и адрес",
              text: "Уточним удобный адрес, время доставки и подскажем доступные варианты получения заказа.",
            },
            {
              icon: Sparkles,
              title: "Персональная помощь",
              text: "Поможем подобрать урбеч, пироги, сыры или пельмени под ваш запрос и количество гостей.",
            },
          ].map((card) => (
            <article className="panel p-5 sm:p-6" key={card.title}>
              <card.icon className="h-6 w-6 text-[var(--color-primary-deep)]" />
              <h2 className="mt-4 font-display text-3xl text-[var(--color-foreground)]">{card.title}</h2>
              <p className="mt-3 text-sm leading-7 text-[var(--color-muted-foreground)]">{card.text}</p>
            </article>
          ))}
        </section>

        <LeadForm
          compact
          description="Опишите вопрос, и мы свяжемся с вами, чтобы помочь с заказом или доставкой."
          heading="Связаться с менеджером"
        />
      </div>
    </div>
  );
}
