import Link from "next/link";

export default function NotFound() {
  return (
    <div className="page-shell py-16">
      <div className="panel flex min-h-[22rem] flex-col items-center justify-center gap-4 p-8 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[var(--color-primary-deep)]/70">404</p>
        <h1 className="font-display text-4xl text-[var(--color-foreground)] sm:text-5xl">Страница не найдена</h1>
        <p className="max-w-xl text-base leading-7 text-[var(--color-muted-foreground)]">
          Похоже, ссылка устарела, страница была удалена или адрес введён с ошибкой.
        </p>
        <Link
          className="inline-flex h-12 items-center justify-center rounded-full bg-[var(--color-primary)] px-6 text-sm font-semibold text-white transition hover:bg-[var(--color-primary-deep)]"
          href="/"
        >
          Вернуться на главную
        </Link>
      </div>
    </div>
  );
}
