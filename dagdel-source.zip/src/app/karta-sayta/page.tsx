import type { Metadata } from "next";
import Link from "next/link";

import { PageHero } from "@/components/site/page-hero";
import { categories, infoPages, products, siteData } from "@/lib/site-data";

export const metadata: Metadata = {
  title: "Карта сайта",
  description: siteData.brand.description,
};

export default function SiteMapPage() {
  return (
    <div className="space-y-8 pb-10 pt-2">
      <div className="page-shell">
        <PageHero
          breadcrumbs={[
            { label: "Главная", href: "/" },
            { label: "Карта сайта" },
          ]}
          description="Все основные разделы, категории и товары в одном месте."
          eyebrow="Карта сайта"
          image={siteData.heroSlides[3]?.image ?? siteData.brand.logoImage}
          title="Карта сайта"
        />
      </div>

      <div className="page-shell grid gap-6 lg:grid-cols-3">
        <section className="panel p-5 sm:p-6">
          <h2 className="font-display text-3xl text-[var(--color-foreground)]">Страницы</h2>
          <div className="mt-4 grid gap-2">
            {[...siteData.navigation.top, ...infoPages.map((page) => ({ label: page.title, href: page.href }))].map((link) => (
              <Link className="rounded-2xl bg-white/75 px-4 py-3 text-sm font-medium text-[var(--color-primary-deep)]" href={link.href} key={link.href}>
                {link.label}
              </Link>
            ))}
          </div>
        </section>

        <section className="panel p-5 sm:p-6">
          <h2 className="font-display text-3xl text-[var(--color-foreground)]">Категории</h2>
          <div className="mt-4 grid gap-2">
            {categories.map((category) => (
              <Link className="rounded-2xl bg-white/75 px-4 py-3 text-sm font-medium text-[var(--color-primary-deep)]" href={category.href} key={category.slug}>
                {category.title}
              </Link>
            ))}
          </div>
        </section>

        <section className="panel p-5 sm:p-6">
          <h2 className="font-display text-3xl text-[var(--color-foreground)]">Товары</h2>
          <div className="mt-4 grid gap-2">
            {products.map((product) => (
              <Link className="rounded-2xl bg-white/75 px-4 py-3 text-sm font-medium text-[var(--color-primary-deep)]" href={product.href} key={product.slug}>
                {product.title}
              </Link>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
