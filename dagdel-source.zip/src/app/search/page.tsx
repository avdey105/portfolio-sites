import type { Metadata } from "next";
import { Suspense } from "react";

import { PageHero } from "@/components/site/page-hero";
import { SearchResultsClient } from "@/components/site/search-results-client";
import { categories, products, siteData } from "@/lib/site-data";

export const metadata: Metadata = {
  title: "Поиск",
  description: siteData.brand.description,
};

export default function SearchPage() {
  return (
    <div className="space-y-8 pb-10 pt-2">
      <div className="page-shell">
        <PageHero
          breadcrumbs={[
            { label: "Главная", href: "/" },
            { label: "Поиск" },
          ]}
          description="Начните вводить название продукта, и каталог сразу отфильтруется."
          eyebrow="Поиск по каталогу"
          image={siteData.heroSlides[2]?.image ?? siteData.brand.logoImage}
          title="Найти продукт"
        />
      </div>

      <div className="page-shell">
        <Suspense fallback={null}>
          <SearchResultsClient categories={categories} products={products} />
        </Suspense>
      </div>
    </div>
  );
}
