import type { MetadataRoute } from "next";

import { categories, infoPages, products, siteData } from "@/lib/site-data";

const BASE_URL = "https://avdey105.github.io/portfolio-sites/urbech";

export const dynamic = "force-static";

export default function sitemap(): MetadataRoute.Sitemap {
  const staticRoutes = [
    "/",
    "/search",
    "/karta-sayta",
    "/cabinet",
    "/shop/cart",
    ...infoPages.map((page) => page.href),
    ...categories.map((category) => category.href),
    ...products.map((product) => product.href),
  ];

  return staticRoutes.map((route) => ({
    url: new URL(route, BASE_URL).toString(),
    lastModified: siteData.generatedAt,
    changeFrequency: route.includes("/shop/product/") ? "weekly" : "monthly",
    priority: route === "/" ? 1 : route.includes("/shop/product/") ? 0.7 : 0.8,
  }));
}
