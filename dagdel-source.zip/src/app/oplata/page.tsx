import type { Metadata } from "next";

import { PageHero } from "@/components/site/page-hero";
import { RichText } from "@/components/site/rich-text";
import { getInfoPageBySlug, siteData } from "@/lib/site-data";
import { cleanLegacyContentHtml } from "@/lib/utils";

const page = getInfoPageBySlug("oplata");

export const metadata: Metadata = {
  title: page?.title ?? "Способы оплаты",
  description: page?.excerpt ?? siteData.brand.description,
};

export default function PaymentPage() {
  const cleanBodyHtml = page ? cleanLegacyContentHtml(page.bodyHtml) : "";

  return (
    <div className="space-y-8 pb-10 pt-2">
      <div className="page-shell">
        <PageHero
          breadcrumbs={[
            { label: "Главная", href: "/" },
            { label: "Способы оплаты" },
          ]}
          description={page?.excerpt ?? "Как устроены предоплата и постоплата по текущей модели продаж."}
          eyebrow="Оплата"
          image={siteData.heroSlides[1]?.image ?? siteData.brand.logoImage}
          title={page?.title ?? "Способы оплаты"}
        />
      </div>

      <div className="page-shell grid gap-6 lg:grid-cols-[1fr_0.95fr]">
        <article className="panel p-6 sm:p-8">
          {cleanBodyHtml ? <RichText html={cleanBodyHtml} /> : null}
        </article>

        <div className="space-y-4">
          {[
            "При специальных производственных заказах действует предоплата 50%.",
            "При обычной покупке используется постоплата после подтверждения заказа.",
            "Принимаются наличные и оплата картой по согласованию с менеджером.",
          ].map((item, index) => (
            <article className="panel p-5 sm:p-6" key={item}>
              <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[var(--color-primary-deep)]/70">
                Шаг {index + 1}
              </p>
              <p className="mt-3 text-base leading-7 text-[var(--color-muted-foreground)]">{item}</p>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
}
