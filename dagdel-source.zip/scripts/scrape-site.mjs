import { createHash } from "node:crypto";
import { access, mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { gunzipSync } from "node:zlib";
import { load } from "cheerio";

const BASE_URL = "https://urbech-dag.ru";
const ROOT_DIR = process.cwd();
const DATA_DIR = path.join(ROOT_DIR, "src", "data");
const PUBLIC_ASSETS_DIR = path.join(ROOT_DIR, "public", "source-assets");
const DATA_FILE = path.join(DATA_DIR, "site-data.json");

const INTERNAL_PAGE_SLUGS = new Set(["o-kompanii", "oplata", "kontakty"]);

function cleanText(value = "") {
  return value.replace(/\s+/g, " ").trim();
}

function stripBase(url) {
  return url.startsWith(BASE_URL) ? url.slice(BASE_URL.length) || "/" : url;
}

function absoluteUrl(url) {
  if (!url) {
    return null;
  }

  try {
    return new URL(url, BASE_URL).toString();
  } catch {
    return null;
  }
}

function normalizeAssetUrl(url) {
  const absolute = absoluteUrl(url);

  if (!absolute || absolute.endsWith("/g/spacer.gif")) {
    return null;
  }

  const parsed = new URL(absolute);
  const dIndex = parsed.pathname.indexOf("/d/");

  if (dIndex >= 0) {
    return new URL(parsed.pathname.slice(dIndex), BASE_URL).toString();
  }

  return absolute;
}

function fileNameForUrl(url) {
  const parsed = new URL(url);
  const baseName = path.posix.basename(parsed.pathname);
  const hash = createHash("md5").update(url).digest("hex").slice(0, 8);
  return `${hash}-${baseName}`;
}

async function exists(filePath) {
  try {
    await access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function downloadAsset(url, assetMap) {
  const normalized = normalizeAssetUrl(url);

  if (!normalized) {
    return null;
  }

  if (assetMap.has(normalized)) {
    return assetMap.get(normalized);
  }

  const fileName = fileNameForUrl(normalized);
  const destination = path.join(PUBLIC_ASSETS_DIR, fileName);
  const publicPath = `/source-assets/${fileName}`;

  if (!(await exists(destination))) {
    const response = await fetch(normalized);

    if (!response.ok) {
      throw new Error(`Failed to download asset: ${normalized}`);
    }

    const buffer = Buffer.from(await response.arrayBuffer());
    await writeFile(destination, buffer);
  }

  assetMap.set(normalized, publicPath);
  return publicPath;
}

async function fetchText(url) {
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`Failed to fetch ${url}: ${response.status}`);
  }

  return response.text();
}

async function fetchSitemapUrls() {
  const response = await fetch(`${BASE_URL}/sitemap.4670141.xml.gz`);

  if (!response.ok) {
    throw new Error(`Failed to fetch sitemap: ${response.status}`);
  }

  const buffer = Buffer.from(await response.arrayBuffer());
  const xml = gunzipSync(buffer).toString("utf8");

  return [...xml.matchAll(/<loc>(.*?)<\/loc>/g)].map((match) => match[1]);
}

function toSlug(url) {
  const parsed = new URL(url);
  const parts = parsed.pathname.split("/").filter(Boolean);
  return parts.at(-1) ?? "home";
}

function extractRichHtml($, element) {
  const clone = $(element).clone();

  clone.find("script, style, link, noscript, iframe").remove();
  clone
    .find(".shop-product-data__nav, .shop2-btn-back, .highslide-caption, .remodal, .smart-captcha")
    .remove();

  clone.find("img").each((_, node) => {
    const src = $(node).attr("src");

    if (src && src.includes("/g/spacer.gif")) {
      $(node).remove();
    }
  });

  clone.find("a").each((_, node) => {
    const href = $(node).attr("href");
    const absolute = absoluteUrl(href);

    if (absolute?.startsWith(BASE_URL)) {
      $(node).attr("href", stripBase(absolute));
    }
  });

  return cleanText(clone.text()) ? clone.html()?.trim() ?? "" : "";
}

function extractSummary(html) {
  const $ = load(html || "");
  return cleanText($.text()).slice(0, 220);
}

async function parseHome(assetMap) {
  const html = await fetchText(BASE_URL);
  const $ = load(html);

  const title = cleanText($("title").first().text());
  const description = $('meta[name="description"]').attr("content") ?? "";

  const topNavigation = $(".top-menu > li > a")
    .map((_, node) => ({
      label: cleanText($(node).text()),
      href: stripBase(absoluteUrl($(node).attr("href")) ?? "/"),
    }))
    .get()
    .filter((item) => item.label);

  const categoryNavigation = $(".cat-menu > li > a")
    .map((_, node) => ({
      label: cleanText($(node).text()),
      href: stripBase(absoluteUrl($(node).attr("href")) ?? "/"),
    }))
    .get()
    .filter((item) => item.label);

  const logoImage = await downloadAsset($(".site-logo img").first().attr("src"), assetMap);

  const heroCandidates = [...new Set(html.match(/\/d\/img-20240627[\w.-]+\.(?:jpg|jpeg|png|webp)/g) ?? [])];
  const heroSlides = [];

  for (const relativePath of heroCandidates) {
    const publicPath = await downloadAsset(relativePath, assetMap);

    if (publicPath) {
      heroSlides.push({
        image: publicPath,
        alt: "Дагестанские продукты",
      });
    }
  }

  return {
    title,
    description,
    topNavigation,
    categoryNavigation,
    logoImage,
    heroSlides,
  };
}

async function parseInfoPage(url) {
  const html = await fetchText(url);
  const $ = load(html);
  const slug = toSlug(url);
  const title = cleanText($("h1").first().text());

  if (slug === "kontakty") {
    const contactBlock = $(".localcontacts2").first();
    const bodyHtml = extractRichHtml($, contactBlock);
    const text = cleanText(contactBlock.text());
    const phones = [...new Set(text.match(/\+7\s?\([^)]+\)\s?\d{3}-\d{2}-\d{2}/g) ?? [])];
    const email =
      $('a[href^="mailto:"]').first().attr("href")?.replace("mailto:", "") ??
      text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)?.[0] ??
      "";
    const coordsMatch = html.match(/coords:\s*"([\d.]+),\s*([\d.]+)"/);

    return {
      slug,
      title,
      href: stripBase(url),
      excerpt: cleanText(text).slice(0, 220),
      bodyHtml,
      contacts: {
        phones,
        email,
        address:
          "Московская область, Одинцовский городской округ, рабочий посёлок Заречье, Торговая улица, с1",
        workingHours: "с 8:00 до 18:00",
        coordinates: coordsMatch
          ? {
              lat: Number(coordsMatch[1]),
              lng: Number(coordsMatch[2]),
            }
          : null,
      },
    };
  }

  const wrapper = $(".lpc-content-wrapper").first();
  const bodyHtml = extractRichHtml($, wrapper);

  return {
    slug,
    title,
    href: stripBase(url),
    excerpt: extractSummary(bodyHtml),
    bodyHtml,
  };
}

async function parseCategory(url) {
  const html = await fetchText(url);
  const $ = load(html);
  const slug = toSlug(url);
  const title = cleanText($("h1").first().text());

  const productLinks = [...new Set(
    $('a[href*="/shop/product/"]')
      .map((_, node) => absoluteUrl($(node).attr("href")))
      .get()
      .filter(Boolean),
  )];

  return {
    slug,
    title,
    href: stripBase(url),
    excerpt: `${title} ручной работы по дагестанским рецептам.`,
    productSlugs: productLinks.map((item) => toSlug(item)),
  };
}

async function parseProduct(url, assetMap) {
  const html = await fetchText(url);
  const $ = load(html);
  const slug = toSlug(url);
  const title = cleanText($("h1").first().text());
  const article = cleanText($(".shop2-product-article").first().text()).replace(/^Артикул:\s*/i, "");
  const priceText = cleanText($(".price-current").first().text()) || "Цена по запросу";
  const availability = cleanText($(".shop-product-btn").first().text()) || "В наличии";
  const descriptionHtml = extractRichHtml($, $(".shop-product-data__desc").first());
  const summary = extractSummary(descriptionHtml);
  const categoryNames = $(".shop-product-folders__item")
    .map((_, node) => cleanText($(node).text()))
    .get()
    .filter(Boolean);

  const gallerySources = [
    $(".gr-image-zoom img").first().attr("src"),
    ...$(".highslide")
      .map((_, node) => $(node).attr("href") || $(node).find("img").attr("src"))
      .get(),
  ];

  const gallery = [];

  for (const src of [...new Set(gallerySources.filter(Boolean))]) {
    const imagePath = await downloadAsset(src, assetMap);

    if (imagePath) {
      gallery.push(imagePath);
    }
  }

  return {
    slug,
    title,
    href: stripBase(url),
    article: article || "нет",
    priceText,
    availability,
    mainImage: gallery[0] ?? null,
    gallery,
    summary,
    descriptionHtml,
    categoryNames,
  };
}

async function main() {
  await mkdir(DATA_DIR, { recursive: true });
  await mkdir(PUBLIC_ASSETS_DIR, { recursive: true });

  const sitemapUrls = await fetchSitemapUrls();
  const assetMap = new Map();

  const home = await parseHome(assetMap);

  const categoryUrls = sitemapUrls.filter((item) => item.includes("/shop/folder/"));
  const productUrls = sitemapUrls.filter((item) => item.includes("/shop/product/"));
  const infoPageUrls = sitemapUrls.filter((item) => INTERNAL_PAGE_SLUGS.has(toSlug(item)));

  const categories = [];

  for (const categoryUrl of categoryUrls) {
    categories.push(await parseCategory(categoryUrl));
  }

  const products = [];

  for (const productUrl of productUrls) {
    products.push(await parseProduct(productUrl, assetMap));
  }

  const pages = [];

  for (const infoPageUrl of infoPageUrls) {
    pages.push(await parseInfoPage(infoPageUrl));
  }

  const categoryByName = new Map(categories.map((item) => [item.title, item.slug]));
  const productBySlug = new Map(products.map((item) => [item.slug, item]));

  for (const product of products) {
    const firstCategoryName = product.categoryNames[0];
    product.categorySlug = firstCategoryName ? categoryByName.get(firstCategoryName) ?? "catalog" : "catalog";
    product.relatedSlugs = products
      .filter((item) => item.slug !== product.slug && item.categorySlug === product.categorySlug)
      .slice(0, 4)
      .map((item) => item.slug);
  }

  for (const category of categories) {
    category.products = category.productSlugs
      .map((slug) => productBySlug.get(slug))
      .filter(Boolean)
      .map((item) => item.slug);
    category.heroImage = category.products.length ? productBySlug.get(category.products[0])?.mainImage ?? null : null;
  }

  const contactsPage = pages.find((item) => item.slug === "kontakty");

  const siteData = {
    generatedAt: new Date().toISOString(),
    brand: {
      name: "Дагестанские деликатесы",
      title: home.title,
      description: home.description,
      slogan: "Производство и продажа урбеча",
      logoImage: home.logoImage,
    },
    navigation: {
      top: home.topNavigation,
      categories: home.categoryNavigation,
    },
    heroSlides: home.heroSlides,
    contact: contactsPage?.contacts ?? {
      phones: ["+7 (958) 524-22-22"],
      email: "dag-urbech@mail.ru",
      address:
        "Московская область, Одинцовский городской округ, рабочий посёлок Заречье, Торговая улица, с1",
      workingHours: "с 8:00 до 18:00",
      coordinates: null,
    },
    categories,
    products,
    pages,
  };

  await writeFile(DATA_FILE, `${JSON.stringify(siteData, null, 2)}\n`, "utf8");

  let previousCount = 0;

  if (await exists(DATA_FILE)) {
    try {
      const previous = JSON.parse(await readFile(DATA_FILE, "utf8"));
      previousCount = Array.isArray(previous.products) ? previous.products.length : 0;
    } catch {
      previousCount = 0;
    }
  }

  console.log(
    JSON.stringify(
      {
        categories: categories.length,
        products: products.length,
        pages: pages.length,
        assets: assetMap.size,
        previousProducts: previousCount,
      },
      null,
      2,
    ),
  );
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
