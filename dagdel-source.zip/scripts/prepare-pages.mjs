import { copyFile, readdir, writeFile } from "node:fs/promises";
import { basename, dirname, join, relative, resolve, sep } from "node:path";

const out = resolve("out");
const files = await readdir(out, { recursive: true, withFileTypes: true });
let aliases = 0;

for (const file of files) {
  if (!file.isFile() || !file.name.endsWith(".txt")) continue;

  const path = join(file.parentPath, file.name);
  const parts = relative(out, path).split(sep);
  const offset = parts.findIndex((part) => part.startsWith("__next."));
  if (offset < 0 || offset === parts.length - 1) continue;

  // The Next.js router requests a flat name for prefetched export segments.
  const parent = join(out, ...parts.slice(0, offset));
  const alias = join(parent, parts.slice(offset).join("."));
  if (dirname(alias) !== parent || !basename(alias).startsWith("__next.")) {
    throw new Error("Invalid exported segment path");
  }
  await copyFile(path, alias);
  aliases++;
}

await writeFile(join(out, ".nojekyll"), "");
console.log(`Prepared ${aliases} prefetched segment aliases for GitHub Pages`);
