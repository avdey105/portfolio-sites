(() => {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const viewer = document.createElement('dialog');
  viewer.className = 'chapter-image-viewer';
  viewer.setAttribute('aria-labelledby', 'chapter-image-title');
  viewer.innerHTML = '<header><h2 id="chapter-image-title"></h2><button type="button" aria-label="Закрыть увеличенный экран" autofocus>×</button></header><div><img alt=""></div>';
  document.body.append(viewer);
  const expandedImage = viewer.querySelector('img');
  viewer.querySelector('button').addEventListener('click', () => viewer.close());
  viewer.addEventListener('click', event => { if (event.target === viewer || event.target === expandedImage.parentElement) viewer.close(); });
  viewer.addEventListener('close', () => expandedImage.removeAttribute('src'));
  for (const eventName of ['keydown','wheel','touchstart','touchend']) {
    viewer.addEventListener(eventName, event => event.stopPropagation());
  }
  document.addEventListener('deckchange', () => { if (viewer.open) viewer.close(); });

  for (const figure of document.querySelectorAll('[data-chapter-player]')) {
    const slide = figure.closest('[data-slide]');
    const shots = Array.from(figure.querySelectorAll('.chapter-shot'));
    const modes = Array.from(figure.querySelectorAll('[data-shot-group]'));
    const storyCount = shots.filter(shot => shot.classList.contains('story-shot')).length;
    const play = figure.querySelector('.chapter-toggle');
    const caption = figure.querySelector('.chapter-caption');
    const counter = figure.querySelector('.chapter-counter');
    const zoom = document.createElement('button');
    zoom.type = 'button';
    zoom.className = 'chapter-zoom';
    zoom.title = 'Рассмотреть экран';
    zoom.setAttribute('aria-label', zoom.title);
    figure.querySelector('.chapter-screen').append(zoom);
    let current = 0;
    let playing = false;
    let timer = 0;
    let touch = null;

    function show(index, animate = true) {
      current = (index + shots.length) % shots.length;
      const isStory = current < storyCount;
      const progress = isStory ? current + 1 : current - storyCount + 1;
      const total = isStory ? storyCount : shots.length - storyCount;
      for (const [i, shot] of shots.entries()) {
        shot.hidden = i !== current;
        shot.classList.toggle('is-entering', animate && !reduced.matches && i === current);
      }
      modes.forEach((button, i) => button.setAttribute('aria-pressed', String(i === (isStory ? 0 : 1))));
      const label = shots[current].dataset.caption;
      zoom.hidden = isStory;
      caption.textContent = label;
      counter.textContent = [progress,total].map(n => String(n).padStart(2, '0')).join(' / ');
      counter.dataset.compact = progress + '/' + total;
      counter.setAttribute('aria-label', (isStory ? 'Кадр ' : 'Экран ') + progress + ' из ' + total + '. ' + label);
      play.setAttribute('aria-pressed', String(playing));
      play.setAttribute('aria-label', playing ? 'Приостановить показ кадров' : 'Показать пять кадров сюжета');
      play.title = play.getAttribute('aria-label');
      play.classList.toggle('is-playing', playing);
      window.clearTimeout(timer);
      if (playing && !document.hidden && slide.classList.contains('is-active')) {
        timer = window.setTimeout(() => {
          if (current === storyCount - 1) { playing = false; show(current, false); }
          else show(current + 1);
        }, 2750);
      }
    }
    function choose(index) { playing = false; show(index); }
    zoom.addEventListener('click', () => {
      const shot = shots[current];
      const source = shot.querySelector('.ego-proof-phone,.dag-store-phone,.cold-phone') || shot.querySelector('img');
      if (!source) return;
      expandedImage.alt = source.alt;
      expandedImage.src = source.currentSrc || source.src;
      viewer.querySelector('h2').textContent = shot.dataset.caption;
      viewer.showModal();
    });
    figure.querySelector('[data-shot-prev]').addEventListener('click', () => choose(current - 1));
    figure.querySelector('[data-shot-next]').addEventListener('click', () => choose(current + 1));
    modes[0].addEventListener('click', () => choose(0));
    modes[1].addEventListener('click', () => choose(storyCount));
    play.addEventListener('click', () => {
      playing = !playing;
      show(playing && current >= storyCount - 1 ? 0 : current, false);
    });
    figure.addEventListener('keydown', event => {
      if (event.ctrlKey || event.altKey || event.metaKey || event.shiftKey) return;
      const index = { ArrowLeft: current - 1, ArrowRight: current + 1, Home: 0, End: shots.length - 1 }[event.key];
      if (index === undefined) return;
      event.preventDefault();
      event.stopPropagation();
      choose(index);
    });
    figure.addEventListener('touchstart', event => {
      const finger = event.touches[0];
      touch = event.touches.length === 1 && !event.target.closest('button,a') && !(window.visualViewport?.scale > 1.01)
        ? {x: finger.clientX, y: finger.clientY} : null;
    }, {passive:true});
    figure.addEventListener('touchcancel', () => { touch = null; });
    figure.addEventListener('touchend', event => {
      if (!touch || event.touches.length || !event.changedTouches.length) return;
      const finger = event.changedTouches[0];
      const dx = touch.x - finger.clientX, dy = touch.y - finger.clientY;
      touch = null;
      if (Math.abs(dx) >= 40 && Math.abs(dx) > Math.abs(dy) * 1.4) {
        event.stopPropagation();
        choose(current + Math.sign(dx));
      }
    }, {passive:true});
    function suspend() {
      if (!playing) return;
      playing = false;
      show(current, false);
    }
    reduced.addEventListener('change', event => { if (event.matches) suspend(); });
    document.addEventListener('visibilitychange', () => { if (document.hidden) suspend(); });
    document.addEventListener('deckchange', event => { if (event.detail.id !== slide.id) suspend(); });
    show(0, false);
  }
})();
