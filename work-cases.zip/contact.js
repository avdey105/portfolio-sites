(() => {
  const contact = document.getElementById('contact');
  const picture = contact.querySelector('.calling-print');
  const plate = picture.querySelector('img');
  const stage = contact.querySelector('.calling-headstage');
  const print = contact.querySelector('.calling-headbox');
  const controls = contact.querySelector('.calling-turn');
  const play = controls.querySelector('[data-head-play]');
  const current = controls.querySelector('.calling-angle');
  const images = [...print.querySelectorAll('img')];
  const names = ['Анфас', 'Поворот вправо', 'Вид сзади', 'Поворот влево'];
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  let index = 0;
  let desired = 0;
  let playing = !reduced.matches;
  let timer = 0;
  let request = 0;

  function active() {
    return contact.classList.contains('is-active') && !contact.closest('[inert]') && !document.hidden && !document.querySelector('dialog[open]');
  }

  function updateLabels() {
    const label = playing ? 'Остановить смену ракурсов' : 'Включить смену ракурсов';
    play.setAttribute('aria-label', label);
    play.title = label;
    play.dataset.playing = String(playing);
    current.setAttribute('aria-live', playing ? 'off' : 'polite');
    current.textContent = names[index] + ' · ' + (index + 1) + ' из 4';
    plate.alt = 'Стилизованная 3D-голова Авдея Голубкова в бордовой папке портфолио. ' + names[index] + '.';
  }

  function schedule() {
    clearTimeout(timer);
    if (playing && active() && !reduced.matches) {
      timer = setTimeout(() => show(index + 1), 3000);
    }
  }

  async function show(next, manual = false) {
    if (!active()) return;
    const sequence = ++request;
    clearTimeout(timer);
    if (manual) playing = false;
    const target = (next + images.length) % images.length;
    desired = target;
    const image = images[target];
    if (!image.hasAttribute('src')) image.src = image.dataset.src;
    try {
      await image.decode();
    } catch {
      if (sequence === request) { playing = false; desired = index; updateLabels(); }
      return;
    }
    if (sequence !== request || !active()) return;
    index = target;
    for (const layer of images) layer.hidden = layer !== image;
    stage.dataset.angle = String(index);
    updateLabels();
    schedule();
  }

  // The controls remain horizontal. Only the four views inside the printed
  // rectangle share its perspective projection and responsive photograph crop.
  function fit() {
    if (!plate.naturalWidth) return false;
    const source = [...picture.querySelectorAll('source')].find(node =>
      new URL(node.srcset, document.baseURI).href === plate.currentSrc) || plate;
    if (!source.dataset.quad) return false;
    const [x0,y0,x1,y1,x2,y2,x3,y3] = source.dataset.quad.split(' ').map(Number);
    const dx1=x1-x2, dx2=x3-x2, dy1=y1-y2, dy2=y3-y2;
    const sx=x0-x1+x2-x3, sy=y0-y1+y2-y3, det=dx1*dy2-dx2*dy1;
    const g=(sx*dy2-dx2*sy)/det, h=(dx1*sy-sx*dy1)/det;
    const a=x1-x0+g*x1, b=x3-x0+h*x3, d=y1-y0+g*y1, e=y3-y0+h*y3;
    const matrix=[a/300,d/300,0,g/300,b/400,e/400,0,h/400,0,0,1,0,x0,y0,0,1];
    const scale=Math.max(plate.clientWidth/plate.naturalWidth,plate.clientHeight/plate.naturalHeight);
    const [xp,yp]=getComputedStyle(plate).objectPosition.split(' ').map(v=>parseFloat(v)/100);
    const ox=(plate.clientWidth-plate.naturalWidth*scale)*xp;
    const oy=(plate.clientHeight-plate.naturalHeight*scale)*yp;
    stage.style.transform='translate('+ox+'px,'+oy+'px) scale('+scale+')';
    print.style.transform='matrix3d('+matrix.join(',')+')';
    const u=.5, v=.92, perspective=g*u+h*v+1;
    const cx=ox+scale*(a*u+b*v+x0)/perspective;
    const cy=oy+scale*(d*u+e*v+y0)/perspective;
    // Never pin the viewport controls below the global slide transport.
    const ceiling=document.getElementById('mast').getBoundingClientRect().bottom+21;
    const floor=document.getElementById('transport').getBoundingClientRect().top-22;
    controls.style.left=cx+'px';
    controls.style.top=Math.max(ceiling,Math.min(cy,floor))+'px';
    return true;
  }

  function sync() {
    clearTimeout(timer);
    ++request;
    if (!active()) return;
    if (fit()) controls.hidden = false;
    show(index);
  }

  controls.querySelector('[data-head-prev]').addEventListener('click', () => show(desired - 1, true));
  controls.querySelector('[data-head-next]').addEventListener('click', () => show(desired + 1, true));
  play.addEventListener('click', () => {
    if (reduced.matches) return;
    ++request;
    playing = !playing;
    updateLabels();
    schedule();
  });
  controls.addEventListener('keydown', event => {
    const step = {ArrowLeft:desired-1,ArrowRight:desired+1,Home:0,End:images.length-1}[event.key];
    if (step !== undefined) {
      event.preventDefault();
      show(step, true);
    }
  });
  reduced.addEventListener('change', () => { playing=false;index=0;sync(); });
  new ResizeObserver(() => { if (active() && fit()) controls.hidden=false; }).observe(contact);
  plate.addEventListener('load', sync);
  document.addEventListener('deckchange', sync);
  document.addEventListener('visibilitychange', sync);
  document.getElementById('contents').addEventListener('toggle', sync);
  updateLabels();
  sync();
})();

