(() => {
  const archive = document.querySelector('.folio-archive');
  if (!archive) return;
  const choices = archive.querySelector('.folio-choices');
  const browser = archive.querySelector('.folio-browser');
  const pager = archive.querySelector('.folio-pager');
  const gallery = archive.querySelector('.folio-gallery');
  const status = archive.querySelector('.folio-status');
  const compact = matchMedia('(max-aspect-ratio: 1/1) and (max-width: 950px), (min-aspect-ratio: 1/1) and (max-height: 540px)');
  const groups = Array.from(browser.querySelectorAll('[data-group-choice]'));
  const pieces = Array.from(archive.querySelectorAll('[data-case]'));
  const entries = new Map();
  let active = '';
  for (const group of groups) {
    const key = group.dataset.groupChoice;
    for (const piece of pieces.filter(item => item.dataset.group === key)) {
      const name = piece.querySelector('h3').textContent;
      const slug = piece.dataset.case;
      const button = document.createElement('button');
      button.type = 'button';
      const thumb = document.createElement('span');
      thumb.className = 'folio-thumb';
      thumb.setAttribute('aria-hidden', 'true');
      const original = piece.querySelector('.folio-frame img');
      if (original) {
        const image = document.createElement('img');
        image.src = piece.dataset.thumbnail || original.getAttribute('src');
        image.alt = '';
        image.loading = 'lazy';
        image.decoding = 'async';
        thumb.append(image);
      } else {
        thumb.classList.add('is-stat');
        thumb.textContent = piece.querySelector('.folio-stat b').textContent;
      }
      const title = document.createElement('span');
      title.textContent = name;
      button.append(thumb, title);
      button.dataset.caseChoice = slug;
      piece.id = 'folio-case-' + slug;
      button.setAttribute('aria-controls', piece.id);
      button.addEventListener('click', () => show(slug));
      choices.append(button);
      entries.set(slug, {piece, button, group:key, name});
    }
    group.addEventListener('click', () => show(key));
  }
  const order = Array.from(entries.keys());
  function updateEdges() {
    choices.classList.toggle('has-earlier', choices.scrollLeft > 1);
    choices.classList.toggle('has-later', choices.scrollWidth - choices.clientWidth - choices.scrollLeft > 1);
  }
  choices.addEventListener('scroll', updateEdges, {passive:true});
  new ResizeObserver(updateEdges).observe(choices);
  function revealChoice(button) {
    if (!compact.matches) return;
    const bounds = choices.getBoundingClientRect();
    const target = button.getBoundingClientRect();
    if (target.left < bounds.left + 12 || target.right > bounds.right - 12) {
      choices.scrollLeft += target.left - bounds.left - (bounds.width - target.width) / 2;
    }
    updateEdges();
  }
  // Incoming case pages and old category links can target the same archive panel.
  function show(key) {
    if (!entries.has(key)) key = pieces.find(piece => piece.dataset.group === key)?.dataset.case;
    if (!entries.has(key)) return false;
    const selected = entries.get(key);
    const animate = active !== '' && active !== key && archive.classList.contains('is-active') &&
      !matchMedia('(prefers-reduced-motion: reduce)').matches;
    active = key;
    for (const [slug, entry] of entries) {
      entry.piece.hidden = slug !== key;
      entry.button.dataset.inGroup = String(entry.group === selected.group);
      entry.button.tabIndex = slug === key ? 0 : -1;
      entry.button.setAttribute('aria-pressed', String(slug === key));
    }
    for (const group of groups) group.setAttribute('aria-pressed',String(group.dataset.groupChoice === selected.group));
    revealChoice(selected.button);
    status.textContent = selected.name + ', ' + (order.indexOf(key) + 1) + ' из ' + order.length;
    if (animate && selected.piece.animate)
      selected.piece.animate([{opacity:.4,transform:'translateY(4px)'},{opacity:1,transform:'translateY(0)'}],{duration:190,easing:'ease-out'});
    return true;
  }
  function step(direction) {
    show(order[(order.indexOf(active) + direction + order.length) % order.length]);
  }
  pager.addEventListener('click', event => {
    const button = event.target.closest('[data-archive-step]');
    if (button) step(Number(button.dataset.archiveStep));
  });
  pager.addEventListener('keydown', event => {
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
      event.preventDefault();
      step(event.key === 'ArrowLeft' ? -1 : 1);
    }
  });
  compact.addEventListener('change', () => revealChoice(entries.get(active).button));
  choices.addEventListener('wheel', event => {
    if (compact.matches && Math.abs(event.deltaX) > Math.abs(event.deltaY)) event.stopPropagation();
  }, {passive:true});

  // Route horizontal swipes on the artwork to the archive. Vertical swipes still reach the deck.
  let origin = null;
  gallery.addEventListener('touchstart', event => {
    origin = null;
    if (!compact.matches || event.touches.length !== 1 || window.visualViewport?.scale > 1.01 || !event.target.closest('.folio-frame')) return;
    const point = event.touches[0];
    origin = {x:point.clientX, y:point.clientY};
  }, {passive:true});
  gallery.addEventListener('touchcancel', () => { origin = null; }, {passive:true});
  gallery.addEventListener('touchend', event => {
    const start = origin;
    origin = null;
    if (!start || event.touches.length || !event.changedTouches.length || window.getSelection()?.toString()) return;
    const point = event.changedTouches[0];
    const dx = start.x - point.clientX;
    if (Math.abs(dx) < 40 || Math.abs(dx) <= Math.abs(start.y - point.clientY)) return;
    event.preventDefault();
    event.stopPropagation();
    step(Math.sign(dx));
  }, {passive:false});
  browser.addEventListener('keydown', event => {
    if (!['ArrowDown','ArrowUp','ArrowRight','ArrowLeft','Home','End','PageDown','PageUp',' '].includes(event.key)) return;
    event.stopPropagation();
    if (event.key === ' ' || !event.target.matches('button')) return;
    const buttons = event.target.hasAttribute('data-case-choice') ? Array.from(choices.children).filter(button => compact.matches || button.dataset.inGroup === 'true') : groups;
    const index = buttons.indexOf(event.target);
    if (index < 0) return;
    const next = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 :
      (index + (['ArrowLeft','ArrowUp','PageUp'].includes(event.key) ? buttons.length - 1 : 1)) % buttons.length;
    event.preventDefault();
    buttons[next].click();
    buttons[next].focus({preventScroll:true});
  });
  window.portfolioArchive = {select:show};
  show(pieces[0].dataset.case);
})();
