(() => {
  const archive = document.querySelector('.folio-archive');
  if (!archive) return;
  const choices = archive.querySelector('.folio-choices');
  const select = archive.querySelector('.folio-select');
  const browser = archive.querySelector('.folio-browser');
  const groups = Array.from(browser.querySelectorAll('[data-group-choice]'));
  const pieces = Array.from(archive.querySelectorAll('[data-case]'));
  const entries = new Map();
  let active = '';
  for (const group of groups) {
    const key = group.dataset.groupChoice;
    const optionGroup = document.createElement('optgroup');
    optionGroup.label = group.textContent;
    for (const piece of pieces.filter(item => item.dataset.group === key)) {
      const name = piece.querySelector('h3').textContent;
      const slug = piece.dataset.case;
      const button = document.createElement('button');
      button.type = 'button';
      const thumb = document.createElement('span');
      thumb.className = 'folio-thumb';
      thumb.setAttribute('aria-hidden', 'true');
      const original = piece.querySelector('.folio-frame img');
      if (original) {
        const image = document.createElement('img');
        image.src = piece.dataset.thumbnail || original.getAttribute('src');
        image.alt = '';
        image.loading = 'lazy';
        image.decoding = 'async';
        thumb.append(image);
      } else {
        thumb.classList.add('is-stat');
        thumb.textContent = piece.querySelector('.folio-stat b').textContent;
      }
      const title = document.createElement('span');
      title.textContent = name;
      button.append(thumb, title);
      button.dataset.caseChoice = slug;
      button.addEventListener('click', () => show(slug));
      choices.append(button);
      optionGroup.append(new Option(name, slug));
      entries.set(slug, {piece, button, group:key});
    }
    select.append(optionGroup);
    group.addEventListener('click', () => show(key));
  }
  // Incoming case pages and old category links can target the same archive panel.
  function show(key) {
    if (!entries.has(key)) key = pieces.find(piece => piece.dataset.group === key)?.dataset.case;
    if (!entries.has(key)) return false;
    const selected = entries.get(key);
    const animate = active !== '' && active !== key && archive.classList.contains('is-active') &&
      !matchMedia('(prefers-reduced-motion: reduce)').matches;
    active = key;
    for (const [slug, entry] of entries) {
      entry.piece.hidden = slug !== key;
      entry.button.hidden = entry.group !== selected.group;
      entry.button.setAttribute('aria-pressed', String(slug === key));
    }
    for (const group of groups) group.setAttribute('aria-pressed',String(group.dataset.groupChoice === selected.group));
    select.value = key;
    if (animate && selected.piece.animate)
      selected.piece.animate([{opacity:.4,transform:'translateY(4px)'},{opacity:1,transform:'translateY(0)'}],{duration:190,easing:'ease-out'});
    return true;
  }
  select.addEventListener('change', () => show(select.value));
  browser.addEventListener('keydown', event => {
    if (!['ArrowDown','ArrowUp','ArrowRight','ArrowLeft','Home','End','PageDown','PageUp',' '].includes(event.key)) return;
    event.stopPropagation();
    if (event.target === select || event.key === ' ' || !event.target.matches('button')) return;
    const buttons = event.target.hasAttribute('data-case-choice') ? Array.from(choices.querySelectorAll('button:not([hidden])')) : groups;
    const index = buttons.indexOf(event.target);
    if (index < 0) return;
    const next = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 :
      (index + (['ArrowLeft','ArrowUp','PageUp'].includes(event.key) ? buttons.length - 1 : 1)) % buttons.length;
    event.preventDefault();
    buttons[next].focus();
    buttons[next].click();
  });
  window.portfolioArchive = {select:show};
  show(pieces[0].dataset.case);
})();
