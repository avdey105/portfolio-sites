(() => {
  const slide = document.getElementById('web');
  const video = slide?.querySelector('[data-welcome-loop]');
  if (!video) return;

  const button = slide.querySelector('.welcome-motion');
  const contents = document.getElementById('contents');
  const portrait = matchMedia('(max-aspect-ratio: 4/5)');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const unavailable = new Set();
  let userPaused = false;
  let revision = 0;

  function updateButton(playing) {
    button.textContent = playing ? 'Пауза' : 'Воспроизвести';
    button.setAttribute('aria-label', playing ? 'Приостановить фоновое видео' : 'Воспроизвести фоновое видео');
    button.hidden = false;
  }

  function visible() {
    return slide.classList.contains('is-active') && !video.closest('[hidden][data-welcome-frame]') && !document.hidden &&
      !document.body.hasAttribute('data-reading') && !contents.open;
  }

  function sync() {
    const request = ++revision;
    const next = reduced.matches ? null : video.dataset[portrait.matches ? 'phone' : 'wide'];
    const previous = video.getAttribute('src');
    if (!next || next !== previous) {
      video.hidden = true;
      button.hidden = true;
      if (previous) {
        video.pause();
        video.removeAttribute('src');
        video.load();
      }
    }
    if (!next || unavailable.has(next) || !visible()) {
      video.pause();
      return;
    }
    if (userPaused) {
      video.pause();
      updateButton(false);
      return;
    }
    if (video.getAttribute('src') !== next) video.src = next;
    video.play().catch(error => {
      if (request !== revision || error.name === 'AbortError') return;
      if (error.name === 'NotAllowedError') {
        updateButton(false);
      } else {
        unavailable.add(next);
        video.hidden = true;
        button.hidden = true;
      }
    });
  }

  video.addEventListener('playing', () => {
    if (!visible() || reduced.matches || userPaused) return sync();
    video.hidden = false;
    updateButton(true);
  });
  video.addEventListener('error', () => {
    if (!video.error) return;
    unavailable.add(video.getAttribute('src'));
    video.hidden = true;
    button.hidden = true;
  });
  button.addEventListener('click', () => {
    userPaused = !video.paused;
    sync();
  });
  document.addEventListener('deckchange', sync);
  document.addEventListener('visibilitychange', sync);
  contents.addEventListener('toggle', sync);
  reduced.addEventListener('change', sync);
  portrait.addEventListener('change', sync);
  window.addEventListener('pagehide', () => {
    revision++;
    video.pause();
  });
  window.addEventListener('pageshow', sync);
  sync();
})();

