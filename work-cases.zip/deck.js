(() => {
  'use strict';
  const deck = document.getElementById('deck');
  const slides = Array.from(deck.querySelectorAll('[data-slide]'));
  const ids = slides.map(slide => slide.id);
  const intro = document.getElementById('web');
  const frames = Array.from(intro.querySelectorAll('[data-welcome-frame]'));
  const nav = document.getElementById('mast');
  const footer = document.getElementById('transport');
  const contents = document.getElementById('contents');
  const indexLabel = footer.querySelector('.page-index strong');
  const caption = footer.querySelector('.current-label');
  const previous = footer.querySelector('[data-step="-1"]');
  const next = footer.querySelector('[data-step="1"]');
  const nextWord = next.querySelector('.next-word');
  const stops = Array.from(footer.querySelectorAll('.deck-stops a'));
  const reader = document.getElementById('reader');
  const announcement = document.getElementById('announce');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const cases = ['holodok','android','dagdel','candles','partners','modular','yandex-market','wildberries','avito','nedviga','telegram-export','excel-stock','candlestick','power-bi'];
  let active = 0;
  let frame = 1;
  let reading = null;
  let trigger = null;
  let transition;
  const screenForCase = slug => ({holodok:'holodok',android:'alterego',dagdel:'dagdel'}[slug] || 'archive');
  function routeTo(hash, state, replace) {
    if (location.hash === hash) {
      if (replace) history.replaceState(state, '', hash);
      return;
    }
    history[replace ? 'replaceState' : 'pushState'](state, '', hash);
  }
  function notify(id) {
    document.dispatchEvent(new CustomEvent('deckchange', {detail:{id,index:active,frame:id==='web'?frame:undefined}}));
  }
  function warmFrame(number) {
    const image=frames[number-1]?.querySelector('picture img');
    if(image && image.loading==='lazy') image.loading='eager';
  }
  function showFrame(number, inside) {
    frame=Math.max(1,Math.min(frames.length,number));
    intro.dataset.frame=String(frame);
    intro.toggleAttribute('data-has-stepped',inside);
    frames.forEach((item,i)=>{item.hidden=i!==frame-1;});
    const heading=frames[frame-1].querySelector('h2');
    intro.setAttribute('aria-labelledby',heading.id);
    warmFrame(frame);
    warmFrame(frame+1);
    warmFrame(frame-1);
    return heading;
  }
  function showSlide(id, {write=true, animate=true, replace=false, initial=false, direction, number=1}={}) {
    const target = ids.indexOf(id);
    if (target < 0) return;
    const old = slides[active];
    const wasReading = Boolean(reading);
    const restoreFocus = (wasReading && reader?.contains(document.activeElement)) || old.contains(document.activeElement);
    reading=null;
    if (reader) { reader.hidden=true; reader.inert=true; }
    document.body.removeAttribute('data-reading');
    deck.inert=false;deck.removeAttribute('aria-hidden');
    if (contents.open) contents.close();
    clearTimeout(transition);
    const move = target !== active && !wasReading && !initial && animate && !reduced.matches;
    const travel = direction ?? Math.sign(target===active && id==='web' ? number-frame : target-active);
    document.documentElement.style.setProperty('--entry-y', travel < 0 ? '-14px' : '14px');
    slides.forEach((s,i) => {
      s.classList.remove('is-entering','is-leaving');
      s.classList.toggle('is-active',i===target);
      s.inert=i!==target;
      s.setAttribute('aria-hidden',String(i!==target));
    });
    if (move) {
      old.classList.add('is-leaving'); slides[target].classList.add('is-entering');
      transition=setTimeout(()=>{old.classList.remove('is-leaving');slides[target].classList.remove('is-entering')},450);
    }
    active=target;
    const current=slides[target];
    const insideIntro=id==='web' && frames.length>1;
    const heading=insideIntro
      ? showFrame(number, old===current && number!==frame && !wasReading && !initial && animate)
      : current.querySelector('h2');
    if(id==='ai')warmFrame(frames.length);
    document.body.dataset.tone=current.dataset.tone;
    indexLabel.textContent=String(target+1).padStart(2,'0');
    caption.textContent=insideIntro ? current.dataset.label+' · '+frame+'/'+frames.length : current.dataset.label;
    previous.setAttribute('aria-label',insideIntro && frame>1?'Предыдущий кадр':target===0?'Перейти к последнему слайду':'Предыдущий слайд');
    next.setAttribute('aria-label',insideIntro && frame<frames.length?'Следующий кадр':target===slides.length-1?'Вернуться на первый слайд':'Следующий слайд');
    nextWord.textContent=target===slides.length-1?'В начало':'Дальше';
    stops.forEach((stop,i)=>{
      if(i===target)stop.setAttribute('aria-current','step');else stop.removeAttribute('aria-current');
    });
    contents.querySelectorAll('a').forEach(a=>{
      if(a.hash==='#'+id)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');
    });
    nav.querySelectorAll('nav a').forEach(a=>{
      const selected=a.hash==='#'+id || (a.hash==='#holodok' && target>=5 && target<=7);
      if(selected)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current');
    });
    document.title=current.dataset.label+' — Авдей Голубков';
    if(write)routeTo(insideIntro && frame>1 ? '#web/'+frame : '#'+id,{kind:'slide',id},replace);
    if(restoreFocus){
      if(wasReading && trigger?.isConnected && current.contains(trigger) && !trigger.closest('[hidden]'))trigger.focus({preventScroll:true});
      else if(heading){heading.tabIndex=-1;heading.focus({preventScroll:true});}
    }
    if(!initial)announcement.textContent=insideIntro
      ? current.dataset.label+'. Кадр '+frame+' из '+frames.length+'. '+heading.innerText.replace(/\s+/g,' ')
      : 'Слайд '+(target+1)+' из '+slides.length+'. '+current.dataset.label;
    notify(id);
  }
  function openCase(slug, page=1, opts={}) {
    if(!cases.includes(slug) || !reader || !window.portfolioReader) return false;
    const same = reading?.slug===slug;
    const origin = opts.origin || (same ? reading.from : ids[active]);
    const from = ids.includes(origin) ? origin : screenForCase(slug);
    const owned = opts.owned ?? (same ? reading.owned : true);
    if (contents.open) contents.close();
    if(!same) {
      if(opts.write!==false) trigger=document.activeElement;
      reader.hidden=false;reader.inert=false;
      document.body.dataset.reading='true';
      deck.inert=true;deck.setAttribute('aria-hidden','true');
    }
    const info=window.portfolioReader.render(slug,Math.max(1,Number(page)||1));
    if (!info) {showSlide(from,{write:false,animate:false});return false;}
    reading={slug,page:info.page,total:info.total,from,owned};
    if(opts.write!==false)routeTo('#case/'+slug+'/'+info.page,{kind:'case',from,owned},same);
    if(opts.write===false && Number(page)!==info.page)routeTo('#case/'+slug+'/'+info.page,{kind:'case',from,owned},true);
    if(!same){
      const h=reader.querySelector('h1,h2,[data-reader-title]') || reader;
      h.tabIndex=-1;h.focus({preventScroll:true});
    }
    document.title=info.title+' — Авдей Голубков';
    announcement.textContent=info.title+'. Страница '+info.page+' из '+info.total;
    notify('reader');
    return true;
  }
  function closeCase() {
    if(!reading)return;
    if(reading.owned)history.back();
    else {
      const from=reading.from, slug=reading.slug;
      showSlide(from,{replace:true,animate:false});
      if(from==='archive')window.portfolioArchive?.select(slug);
    }
  }
  function step(direction) {
    if(contents.open)return;
    if(reading) {
      const page=reading.page+direction;
      if(page>=1 && page<=reading.total)openCase(reading.slug,page);
      return;
    }
    if(ids[active]==='web' && frame+direction>=1 && frame+direction<=frames.length) {
      showSlide('web',{number:frame+direction,direction});
      return;
    }
    const target=(active + direction + slides.length) % slides.length;
    showSlide(ids[target], {direction,number:ids[target]==='web' && direction<0 ? frames.length : 1});
  }
  function loadRoute(initial=false) {
    const hash=location.hash.slice(1);
    const introRoute=/^web\/(\d+)$/.exec(hash);
    if(introRoute && frames.length) {
      const number=Math.min(frames.length,Math.max(1,Number(introRoute[1])));
      showSlide('web',{write:false,animate:!initial,initial,number});
      const path=number===1?'#web':'#web/'+number;
      if(path!==location.hash)routeTo(path,{kind:'slide',id:'web'},true);
      return;
    }
    const archiveSelection = /^archive\/([\w-]+)$/.exec(hash);
    if (archiveSelection && window.portfolioArchive?.select(archiveSelection[1])) {
      showSlide('archive',{write:false,animate:!initial,initial});
      return;
    }
    const match=/^case\/([\w-]+)(?:\/(\d+))?$/.exec(hash);
    if(match && cases.includes(match[1])) {
      const from=history.state?.from || screenForCase(match[1]);
      if(!reading && ids[active]!==from)showSlide(from,{write:false,animate:false,initial:true});
      if(!reading && from==='archive' && !history.state?.owned)window.portfolioArchive?.select(match[1]);
      if(openCase(match[1],Number(match[2])||1,{write:false,origin:from,owned:Boolean(history.state?.owned)}))return;
    }
    const alias={top:'web',work:'holodok',data:'archive',trade:'archive','lx-sites':'archive',about:'contact'};
    const oldLook=new URLSearchParams(location.search).get('look');
    const target=ids.includes(hash)?hash:alias[hash]||(!hash && /^[0-4]$/.test(oldLook||'')?ids[Number(oldLook)]:'web');
    showSlide(target,{write:false,animate:!initial,initial});
    if(hash==='data'||hash==='trade')window.portfolioArchive?.select(hash);
  }
  window.portfolioDeck={openCase,closeCase,go:id=>showSlide(id),get current(){
    if(reading)return {...reading};
    return ids[active]==='web' && frames.length ? {id:'web',frame} : {id:ids[active]};
  }};
  window.addEventListener('hashchange',()=>loadRoute());
  document.addEventListener('readerreflow',e=>{
    if(!reading||e.detail.slug!==reading.slug)return;
    reading.page=e.detail.page;reading.total=e.detail.total;
    routeTo('#case/'+reading.slug+'/'+reading.page,{kind:'case',from:reading.from,owned:reading.owned},true);
  });
  footer.querySelector('.contents-trigger').addEventListener('click',()=>{
    contents.showModal();
    (contents.querySelector('[aria-current="page"]') || contents.querySelector('button')).focus({preventScroll:true});
  });
  contents.addEventListener('click',e=>{if(e.target===contents){
    const r=contents.getBoundingClientRect();
    if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)contents.close();
  }});
  previous.addEventListener('click',()=>step(-1));
  next.addEventListener('click',()=>step(1));
  document.addEventListener('click',event=>{
    if(event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
    const a=event.target.closest?.('a[href]');
    if(!a)return;
    const href=a.getAttribute('href');
    const project=/^(?:\.\/)?cases\/([\w-]+)\/(?:index\.html)?$/.exec(href);
    const chapter=/^#case\/([\w-]+)(?:\/(\d+))?$/.exec(href);
    if((project||chapter) && openCase((project||chapter)[1],Number(chapter?.[2])||1)){event.preventDefault();return;}
    if(href.startsWith('#') && ids.includes(href.slice(1))){
      event.preventDefault();showSlide(href.slice(1));
    }
  });
  function editing(target) {return target.closest?.('input,textarea,select,[contenteditable="true"]');}
  document.addEventListener('keydown',e=>{
    if(e.defaultPrevented||e.ctrlKey||e.metaKey||e.altKey||editing(e.target)||contents.open)return;
    if(e.key==='Escape'&&reading){e.preventDefault();closeCase();return;}
    if(e.target.closest?.('[data-deck-widget]') && ['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
    const map={ArrowDown:1,ArrowRight:1,PageDown:1,ArrowUp:-1,ArrowLeft:-1,PageUp:-1};
    let dir=map[e.key];
    if(e.key===' ' && !e.target.closest?.('a,button,video'))dir=e.shiftKey?-1:1;
    if(dir){
      e.preventDefault();if(!e.repeat)step(dir);
    }else if(e.key==='Home'||e.key==='End'){
      e.preventDefault();if(e.repeat)return;
      if(reading)openCase(reading.slug,e.key==='Home'?1:reading.total);
      else showSlide(e.key==='Home'?ids[0]:ids.at(-1));
    }
  });
  // One trackpad gesture includes its diminishing inertia tail, even after the transition ends.
  let lastWheel=0, lastMagnitude=0, lastWheelStep=0, repeatedDetents=0;
  let wheelAmount=0, wheelFired=false, wheelDirection=0;
  window.addEventListener('wheel',e=>{
    if(e.ctrlKey||e.metaKey||e.defaultPrevented||editing(e.target)||contents.open)return;
    const delta=Math.abs(e.deltaY)>=Math.abs(e.deltaX)?e.deltaY:e.deltaX;
    if(!delta)return;
    e.preventDefault();
    const now=e.timeStamp, dir=Math.sign(delta), gap=now-lastWheel;
    const magnitude=Math.abs(delta)*(e.deltaMode===1?16:e.deltaMode===2?innerHeight:1);
    // Regular mouse-wheel detents can continue indefinitely, while a single
    // touchpad flick produces closely spaced and then diminishing deltas.
    const samePulse=dir===wheelDirection && gap<=170 && magnitude===lastMagnitude;
    repeatedDetents=samePulse?repeatedDetents+1:1;
    const coarseUnits=e.deltaMode!==0 || magnitude===100 || magnitude===120;
    const regular=samePulse && magnitude>=40 && (gap>=50 || (coarseUnits && repeatedDetents>=4));
    const nextDetent=regular && now-lastWheelStep>=400;
    // A declining inertia tail may arrive late while a new slide is decoding.
    const lateTail=wheelFired && dir===wheelDirection && magnitude<lastMagnitude && gap<=320;
    if((gap>170 && !lateTail) || dir!==wheelDirection || nextDetent){wheelAmount=0;wheelFired=false;}
    lastWheel=now;wheelDirection=dir;lastMagnitude=magnitude;
    wheelAmount+=magnitude;
    if(!wheelFired&&wheelAmount>=36){wheelFired=true;lastWheelStep=now;step(dir);}
  },{passive:false});
  let touch=null;
  window.addEventListener('touchstart',e=>{
    touch=null;
    if(e.touches.length!==1||contents.open||editing(e.target)||e.target.closest?.('button,a,[data-no-swipe]')||window.visualViewport?.scale>1.01)return;
    const p=e.touches[0];touch={x:p.clientX,y:p.clientY};
  },{passive:true});
  window.addEventListener('touchcancel',()=>{touch=null},{passive:true});
  window.addEventListener('touchend',e=>{
    const origin=touch;touch=null;
    if(!origin||e.touches.length||!e.changedTouches.length)return;
    const p=e.changedTouches[0], dx=origin.x-p.clientX,dy=origin.y-p.clientY;
    const delta=Math.abs(dy)>=Math.abs(dx)?dy:dx;
    if(Math.abs(delta)>=48 && !window.getSelection()?.toString())step(Math.sign(delta));
  },{passive:true});
  loadRoute(true);
})();
