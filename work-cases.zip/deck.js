(() => {
  'use strict';
  const deck = document.getElementById('deck');
  const slides = Array.from(deck.querySelectorAll('[data-slide]'));
  const ids = slides.map(slide => slide.id);
  const nav = document.getElementById('mast');
  const footer = document.getElementById('transport');
  const contents = document.getElementById('contents');
  const indexLabel = footer.querySelector('.page-index strong');
  const caption = footer.querySelector('.current-label');
  const previous = footer.querySelector('[data-step="-1"]');
  const next = footer.querySelector('[data-step="1"]');
  const nextWord = next.querySelector('.next-word');
  const stops = Array.from(footer.querySelectorAll('.deck-stops a'));
  const reader = document.getElementById('reader');
  const browserTheme = document.querySelector('meta[name="theme-color"]');
  const announcement = document.getElementById('announce');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const cases = ['holodok','android','dagdel','candles','partners','modular','yandex-market','wildberries','avito','nedviga','telegram-export','excel-stock','candlestick','power-bi'];
  let active = 0;
  let reading = null;
  let trigger = null;
  let transition;
  const screenForCase = slug => ({holodok:'holodok',android:'alterego',dagdel:'dagdel'}[slug] || 'archive');
  function routeTo(hash, state, replace) {
    if (location.hash === hash) {
      if (replace) history.replaceState(state, '', hash);
      return;
    }
    history[replace ? 'replaceState' : 'pushState'](state, '', hash);
  }
  function notify(id) {
    const surface = id === 'reader' ? reader : slides[active];
    const style = getComputedStyle(surface);
    const tint = style.getPropertyValue('--browser-tint').trim() || style.backgroundColor;
    browserTheme.content = tint;
    document.documentElement.style.setProperty('--browser-chrome', tint);
    document.dispatchEvent(new CustomEvent('deckchange', {detail:{id,index:active,frame:id==='web'?1:undefined}}));
  }
  function showSlide(id, {write=true, animate=true, replace=false, initial=false, direction}={}) {
    const target = ids.indexOf(id);
    if (target < 0) return;
    const old = slides[active];
    const wasReading = Boolean(reading);
    const restoreFocus = (wasReading && reader?.contains(document.activeElement)) || old.contains(document.activeElement);
    reading=null;
    if (reader) { reader.hidden=true; reader.inert=true; }
    document.body.removeAttribute('data-reading');
    deck.inert=false;deck.removeAttribute('aria-hidden');
    if (contents.open) contents.close();
    clearTimeout(transition);
    const move = target !== active && !wasReading && !initial && animate && !reduced.matches;
    const travel = direction ?? Math.sign(target-active);
    document.documentElement.style.setProperty('--entry-y', travel < 0 ? '-14px' : '14px');
    slides.forEach((s,i) => {
      s.classList.remove('is-entering','is-leaving');
      s.classList.toggle('is-active',i===target);
      s.inert=i!==target;
      s.setAttribute('aria-hidden',String(i!==target));
    });
    if (move) {
      old.classList.add('is-leaving'); slides[target].classList.add('is-entering');
      transition=setTimeout(()=>{old.classList.remove('is-leaving');slides[target].classList.remove('is-entering')},450);
    }
    active=target;
    const current=slides[target];
    const heading=current.querySelector('h2');
    document.body.dataset.tone=current.dataset.tone;
    indexLabel.textContent=String(target+1).padStart(2,'0');
    caption.textContent=current.dataset.label;
    previous.setAttribute('aria-label',target===0?'Перейти к последнему слайду':'Предыдущий слайд');
    next.setAttribute('aria-label',target===slides.length-1?'Вернуться на первый слайд':'Следующий слайд');
    nextWord.textContent=target===slides.length-1?'В начало':'Дальше';
    stops.forEach((stop,i)=>{
      if(i===target)stop.setAttribute('aria-current','step');else stop.removeAttribute('aria-current');
    });
    contents.querySelectorAll('a').forEach(a=>{
      if(a.hash==='#'+id)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');
    });
    nav.querySelectorAll('nav a').forEach(a=>{
      const selected=a.hash==='#'+id || (a.hash==='#holodok' && current.classList.contains('project-slide'));
      if(selected)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current');
    });
    document.title=current.dataset.label+' — Авдей Голубков';
    if(write)routeTo('#'+id,{kind:'slide',id},replace);
    if(restoreFocus){
      if(wasReading && trigger?.isConnected && current.contains(trigger) && !trigger.closest('[hidden]'))trigger.focus({preventScroll:true});
      else if(heading){heading.tabIndex=-1;heading.focus({preventScroll:true});}
    }
    if(!initial)announcement.textContent='Слайд '+(target+1)+' из '+slides.length+'. '+current.dataset.label;
    notify(id);
  }
  function openCase(slug, page=1, opts={}) {
    if(!cases.includes(slug) || !reader || !window.portfolioReader) return false;
    const same = reading?.slug===slug;
    const origin = opts.origin || (same ? reading.from : ids[active]);
    const from = ids.includes(origin) ? origin : screenForCase(slug);
    const owned = opts.owned ?? (same ? reading.owned : true);
    if (contents.open) contents.close();
    if(!same) {
      if(opts.write!==false) trigger=document.activeElement;
      reader.hidden=false;reader.inert=false;
      document.body.dataset.reading='true';
      deck.inert=true;deck.setAttribute('aria-hidden','true');
    }
    const info=window.portfolioReader.render(slug,Math.max(1,Number(page)||1));
    if (!info) {showSlide(from,{write:false,animate:false});return false;}
    reading={slug,page:info.page,total:info.total,from,owned};
    if(opts.write!==false)routeTo('#case/'+slug+'/'+info.page,{kind:'case',from,owned},same);
    if(opts.write===false && Number(page)!==info.page)routeTo('#case/'+slug+'/'+info.page,{kind:'case',from,owned},true);
    if(!same){
      const h=reader.querySelector('h1,h2,[data-reader-title]') || reader;
      h.tabIndex=-1;h.focus({preventScroll:true});
    }
    document.title=info.title+' — Авдей Голубков';
    announcement.textContent=info.title+'. Страница '+info.page+' из '+info.total;
    notify('reader');
    return true;
  }
  function closeCase() {
    if(!reading)return;
    if(reading.owned)history.back();
    else {
      const from=reading.from, slug=reading.slug;
      showSlide(from,{replace:true,animate:false});
      if(from==='archive')window.portfolioArchive?.select(slug);
    }
  }
  function step(direction) {
    if(contents.open)return;
    if(reading) {
      const page=reading.page+direction;
      if(page>=1 && page<=reading.total)openCase(reading.slug,page);
      return;
    }
    const target=(active + direction + slides.length) % slides.length;
    showSlide(ids[target], {direction});
  }
  function loadRoute(initial=false) {
    const hash=location.hash.slice(1);
    const introRoute=/^web\/(\d+)$/.exec(hash);
    if(introRoute) {
      const target=Number(introRoute[1])>=4?'contact':'web';
      showSlide(target,{replace:true,animate:!initial,initial});
      return;
    }
    const archiveSelection = /^archive\/([\w-]+)$/.exec(hash);
    if (archiveSelection && window.portfolioArchive?.select(archiveSelection[1])) {
      showSlide('archive',{write:false,animate:!initial,initial});
      return;
    }
    const match=/^case\/([\w-]+)(?:\/(\d+))?$/.exec(hash);
    if(match && cases.includes(match[1])) {
      const from=history.state?.from || screenForCase(match[1]);
      if(!reading && ids[active]!==from)showSlide(from,{write:false,animate:false,initial:true});
      if(!reading && from==='archive' && !history.state?.owned)window.portfolioArchive?.select(match[1]);
      if(openCase(match[1],Number(match[2])||1,{write:false,origin:from,owned:Boolean(history.state?.owned)}))return;
    }
    const alias={top:'web',work:'holodok',shop:'dagdel',data:'archive',trade:'archive','lx-sites':'archive',about:'contact'};
    const oldLook=new URLSearchParams(location.search).get('look');
    const previousLooks=['web','ai','dagdel','bot','analytics'];
    const target=ids.includes(hash)?hash:alias[hash]||(!hash && /^[0-4]$/.test(oldLook||'')?previousLooks[Number(oldLook)]:'web');
    showSlide(target,{write:hash==='shop',replace:true,animate:!initial,initial});
    if(hash==='data'||hash==='trade')window.portfolioArchive?.select(hash);
  }
  window.portfolioDeck={openCase,closeCase,go:id=>showSlide(id),get current(){
    if(reading)return {...reading};
    return ids[active]==='web' ? {id:'web',frame:1} : {id:ids[active]};
  }};
  window.addEventListener('hashchange',()=>loadRoute());
  document.addEventListener('readerreflow',e=>{
    if(!reading||e.detail.slug!==reading.slug)return;
    reading.page=e.detail.page;reading.total=e.detail.total;
    routeTo('#case/'+reading.slug+'/'+reading.page,{kind:'case',from:reading.from,owned:reading.owned},true);
  });
  footer.querySelector('.contents-trigger').addEventListener('click',()=>{
    contents.showModal();
    (contents.querySelector('[aria-current="page"]') || contents.querySelector('button')).focus({preventScroll:true});
  });
  contents.addEventListener('click',e=>{if(e.target===contents){
    const r=contents.getBoundingClientRect();
    if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)contents.close();
  }});
  previous.addEventListener('click',()=>step(-1));
  next.addEventListener('click',()=>step(1));
  document.addEventListener('click',event=>{
    if(event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
    const a=event.target.closest?.('a[href]');
    if(!a)return;
    const href=a.getAttribute('href');
    const project=/^(?:\.\/)?cases\/([\w-]+)\/(?:index\.html)?$/.exec(href);
    const chapter=/^#case\/([\w-]+)(?:\/(\d+))?$/.exec(href);
    if((project||chapter) && openCase((project||chapter)[1],Number(chapter?.[2])||1)){event.preventDefault();return;}
    if(href.startsWith('#') && ids.includes(href.slice(1))){
      event.preventDefault();showSlide(href.slice(1));
    }
  });
  function editing(target) {return target.closest?.('input,textarea,select,[contenteditable="true"]');}
  const copySelector='.cover-copy,.chapter-copy,.folio-caption,.calling-copy';
  function scrollableCopy(target) {
    const box=target.closest?.(copySelector);
    return box && box.scrollHeight>box.clientHeight+2 && getComputedStyle(box).overflowY==='auto' ? box : null;
  }
  function canScroll(box,dir) {
    return box && (dir>0 ? box.scrollTop+box.clientHeight<box.scrollHeight-2 : box.scrollTop>2);
  }
  document.addEventListener('keydown',e=>{
    if(e.defaultPrevented||e.ctrlKey||e.metaKey||e.altKey||editing(e.target)||contents.open)return;
    if(e.key==='Escape'&&reading){e.preventDefault();closeCase();return;}
    if(e.target.closest?.('[data-deck-widget]') && ['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
    const map={ArrowDown:1,ArrowRight:1,PageDown:1,ArrowUp:-1,ArrowLeft:-1,PageUp:-1};
    let dir=map[e.key];
    if(e.key===' ' && !e.target.closest?.('a,button,video'))dir=e.shiftKey?-1:1;
    if(dir){
      if(!reading && !['ArrowLeft','ArrowRight'].includes(e.key)) {
        const box=scrollableCopy(e.target===document.body ? slides[active].querySelector(copySelector) || e.target : e.target);
        if(canScroll(box,dir)) {
          e.preventDefault();
          box.scrollBy(0, dir*(e.key.startsWith('Arrow') ? 40 : box.clientHeight*.85));
          return;
        }
      }
      e.preventDefault();if(!e.repeat)step(dir);
    }else if(e.key==='Home'||e.key==='End'){
      e.preventDefault();if(e.repeat)return;
      if(reading)openCase(reading.slug,e.key==='Home'?1:reading.total);
      else showSlide(e.key==='Home'?ids[0]:ids.at(-1));
    }
  });
  // One trackpad gesture includes its diminishing inertia tail, even after the transition ends.
  let lastWheel=0, lastMagnitude=0, lastWheelStep=0, repeatedDetents=0;
  let wheelAmount=0, wheelFired=false, wheelDirection=0, copyWheel=null;
  window.addEventListener('wheel',e=>{
    if(e.ctrlKey||e.metaKey||e.defaultPrevented||editing(e.target)||contents.open)return;
    const vertical=Math.abs(e.deltaY)>=Math.abs(e.deltaX);
    const delta=vertical?e.deltaY:e.deltaX;
    if(!delta)return;
    const box=vertical && scrollableCopy(e.target);
    if(canScroll(box,delta)) {
      copyWheel={box,dir:Math.sign(delta),time:e.timeStamp};
      return;
    }
    if(box && copyWheel?.box===box && copyWheel.dir===Math.sign(delta) && e.timeStamp-copyWheel.time<160) {
      copyWheel.time=e.timeStamp;
      e.preventDefault();
      return;
    }
    copyWheel=null;
    e.preventDefault();
    const now=e.timeStamp, dir=Math.sign(delta), gap=now-lastWheel;
    const magnitude=Math.abs(delta)*(e.deltaMode===1?16:e.deltaMode===2?innerHeight:1);
    // Regular mouse-wheel detents can continue indefinitely, while a single
    // touchpad flick produces closely spaced and then diminishing deltas.
    const samePulse=dir===wheelDirection && gap<=170 && magnitude===lastMagnitude;
    repeatedDetents=samePulse?repeatedDetents+1:1;
    const coarseUnits=e.deltaMode!==0 || magnitude===100 || magnitude===120;
    const regular=samePulse && magnitude>=40 && (gap>=50 || (coarseUnits && repeatedDetents>=4));
    const nextDetent=regular && now-lastWheelStep>=400;
    // A declining inertia tail may arrive late while a new slide is decoding.
    const lateTail=wheelFired && dir===wheelDirection && magnitude<lastMagnitude && gap<=320;
    if((gap>170 && !lateTail) || dir!==wheelDirection || nextDetent){wheelAmount=0;wheelFired=false;}
    lastWheel=now;wheelDirection=dir;lastMagnitude=magnitude;
    wheelAmount+=magnitude;
    if(!wheelFired&&wheelAmount>=36){wheelFired=true;lastWheelStep=now;step(dir);}
  },{passive:false});
  let touch=null;
  window.addEventListener('touchstart',e=>{
    touch=null;
    if(e.touches.length!==1||contents.open||editing(e.target)||e.target.closest?.('button,a:not(.folio-preview),[data-no-swipe]')||window.visualViewport?.scale>1.01)return;
    const p=e.touches[0],box=scrollableCopy(e.target);
    touch={x:p.clientX,y:p.clientY,box,back:canScroll(box,-1),forward:canScroll(box,1)};
  },{passive:true});
  window.addEventListener('touchmove',e=>{
    if(!touch?.box || e.touches.length!==1)return;
    const dx=touch.x-e.touches[0].clientX,dy=touch.y-e.touches[0].clientY;
    if(Math.abs(dy)>Math.abs(dx) && !(dy>0 ? touch.forward : touch.back) && e.cancelable)e.preventDefault();
  },{passive:false});
  window.addEventListener('touchcancel',()=>{touch=null},{passive:true});
  window.addEventListener('touchend',e=>{
    const origin=touch;touch=null;
    if(!origin||e.touches.length||!e.changedTouches.length)return;
    const p=e.changedTouches[0], dx=origin.x-p.clientX,dy=origin.y-p.clientY;
    const vertical=Math.abs(dy)>=Math.abs(dx);
    if(vertical && origin.box && (dy>0 ? origin.forward : origin.back))return;
    const delta=vertical?dy:dx;
    if(Math.abs(delta)>=48 && !window.getSelection()?.toString())step(Math.sign(delta));
  },{passive:true});
  loadRoute(true);
})();
