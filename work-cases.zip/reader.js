(() => {
  const root = document.getElementById('reader');
  const cases = window.portfolioCases;
  if (!root || !cases) return;
  const find = selector => root.querySelector(selector);
  const story = find('.rd-content');
  const stage = find('.rd-stage');
  const figure = find('.rd-figure');
  const panel = find('.rd-panel');
  const gallery = find('.rd-gallery');
  const photo = find('.rd-image img');
  const full = find('.rd-image');
  const compactSource = find('.rd-detail-source');
  const compact = matchMedia('(max-width: 500px)');
  const source = find('.rd-source');
  let slug = '', page = 1, picture = 0;
  function node(tag, content) {
    const el=document.createElement(tag);
    el.textContent=content;
    return el;
  }
  function showPicture(index, block) {
    picture=index;
    const record=block.pictures[index];
    if(record.compact)compactSource.srcset=record.compact;
    else compactSource.removeAttribute('srcset');
    photo.onload=()=>figure.style.setProperty('--image-ratio',photo.naturalWidth/photo.naturalHeight);
    figure.style.setProperty('--image-ratio', (compact.matches && record.compact ? record.compactRatio : record.ratio) || 1.6);
    photo.src=record.src;
    photo.alt=record.alt;
    full.href=record.full || record.src;
    full.setAttribute('aria-label','Открыть в полном размере. '+record.alt);
    find('.rd-caption').textContent=compact.matches && record.compactCaption ? record.compactCaption : record.caption;
    [...gallery.children].forEach((b,i)=>b.setAttribute('aria-pressed',String(i===index)));
  }
  function drawPanel(evidence) {
    panel.dataset.kind=evidence.kind || '';
    const heading=node('h3',evidence.label);
    let body;
    if(evidence.columns){
      body=node('table','');
      const top=body.createTHead().insertRow();
      evidence.columns.forEach(label=>top.append(node('th',label)));
      const rows=body.createTBody();
      evidence.values.forEach(line=>{
        const row=rows.insertRow();
        line.forEach((v,i)=>row.append(node(i ? 'td' : 'th',v)));
      });
    }else if(evidence.windows){
      body=node('ol','');body.className='rd-windows';
      evidence.windows.forEach(([start,end],i)=>{
        const row=node('li',''),track=node('div',''),range=node('i','');
        row.append(node('span','PNG '+(i+1)+' · строки '+start+'–'+end));
        track.setAttribute('aria-hidden','true');
        range.style.left=(start-1)/evidence.size*100+'%';
        range.style.width=(end-start+1)/evidence.size*100+'%';
        track.append(range);row.append(track);body.append(row);
      });
    }else{
      body=node('dl','');
      evidence.rows.forEach(([name,value])=>{
        const row=node('div','');row.append(node('dt',name),node('dd',value));body.append(row);
      });
    }
    panel.replaceChildren(heading,body);
  }
  function render(id,n=1) {
    const current=cases[id];
    if (!current) return null;
    const slot=Math.max(1,Math.min(current.blocks.length,Math.trunc(Number(n)) || 1));
    const same=slug===id && page===slot;
    slug=id;page=slot;
    const block=current.blocks[slot-1];
    const pics=block.pictures || [];
    root.hidden=false;root.dataset.case=id;root.dataset.page=String(slot);
    root.setAttribute('aria-label',current.title+'. '+block.heading);
    find('.rd-case').textContent=current.title;
    find('.rd-category').textContent=current.category;
    find('.rd-title').textContent=block.heading;
    source.href=current.source.href;
    source.title=current.source.label;
    source.querySelector('.rd-source-name').textContent=current.source.label;
    source.setAttribute('aria-label',current.source.label);
    const items=document.createDocumentFragment();
    for(const p of block.paragraphs)items.append(node('p',p));
    for(const {label,href} of block.links || []){
      if(href===current.source.href)continue;
      const a=node('a',label+' ↗');
      a.href=href;a.target='_blank';a.rel='noopener';items.append(a);
    }
    story.replaceChildren(items);
    figure.hidden=!pics.length;
    panel.hidden=!block.panel;
    stage.classList.toggle('has-image',pics.length>0);
    stage.classList.toggle('has-panel',Boolean(block.panel));
    if(pics.length){
      const chips=pics.length>1 ? pics.map((p,i)=>{
        const button=node('button',String(i+1));button.type='button';button.dataset.readPicture=i;
        button.setAttribute('aria-label','Изображение '+(i+1)+'. '+p.alt);
        return button;
      }) : [];
      gallery.replaceChildren(...chips);
      gallery.hidden=!chips.length;
      showPicture(same && picture<pics.length ? picture : 0,block);
    }
    if(block.panel)drawPanel(block.panel);
    find('.rd-status').textContent=slot+' / '+current.blocks.length;
    find('[data-read-action="prev"]').disabled=slot===1;
    find('[data-read-action="next"]').disabled=slot===current.blocks.length;
    return {page:slot,total:current.blocks.length,title:current.title};
  }
  root.addEventListener('click',e=>{
    const pick=e.target.closest('[data-read-picture]');
    if(pick){showPicture(Number(pick.dataset.readPicture),cases[slug].blocks[page-1]);return;}
    const cmd=e.target.closest('[data-read-action]')?.dataset.readAction;
    if(cmd==='close')window.portfolioDeck?.closeCase();
    if(cmd==='prev'||cmd==='next')window.portfolioDeck?.openCase(slug,page+(cmd==='next'?1:-1));
  });
  compact.addEventListener('change',()=>{
    if(!slug || root.hidden)return;
    const block=cases[slug].blocks[page-1];
    if(block.pictures?.length)showPicture(picture,block);
  });
  window.portfolioReader={render};
})();
