"use strict";

const mobileMenu = document.querySelector(".mobile-menu-btn");
const navigation = document.getElementById("primary-navigation");
const header = document.querySelector(".header");

function setMenu(open) {
  navigation.classList.toggle("is-open", open);
  mobileMenu.setAttribute("aria-expanded", String(open));
  mobileMenu.setAttribute("aria-label", open ? "Закрыть меню" : "Открыть меню");
}

if (mobileMenu && navigation && header) {
  mobileMenu.addEventListener("click", () => setMenu(mobileMenu.getAttribute("aria-expanded") !== "true"));
  navigation.addEventListener("click", event => {
    if (event.target.closest("a")) setMenu(false);
  });
  document.addEventListener("click", event => {
    if (!header.contains(event.target)) setMenu(false);
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape" && mobileMenu.getAttribute("aria-expanded") === "true") {
      setMenu(false);
      mobileMenu.focus();
    }
  });
}

const symptom = document.getElementById("demo-symptom");
const preview = document.getElementById("demo-preview");
const feedback = document.getElementById("demo-feedback");

preview.addEventListener("click", () => {
  if (!symptom.value) {
    feedback.textContent = "Выберите один из симптомов.";
    symptom.focus();
    return;
  }
  feedback.textContent = `Выбран симптом «${symptom.value}». Это локальный предпросмотр.`;
});
symptom.addEventListener("change", () => { feedback.textContent = ""; });
