(() => {
  const modal = document.getElementById("privacy-modal");
  if (!modal) return;

  const dialog = modal.querySelector(".privacy-modal__dialog");
  const openers = [...document.querySelectorAll("[data-privacy-open]")];
  const closers = [...modal.querySelectorAll("[data-privacy-close]")];
  let returnFocus = null;

  const focusable = () => [...dialog.querySelectorAll(
    'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
  )].filter(element => !element.hidden && element.getClientRects().length);

  const openModal = opener => {
    returnFocus = opener || document.activeElement;
    modal.hidden = false;
    document.body.classList.add("is-privacy-modal-open");
    window.requestAnimationFrame(() => dialog.focus({ preventScroll: true }));
  };

  const closeModal = () => {
    if (modal.hidden) return;
    modal.hidden = true;
    document.body.classList.remove("is-privacy-modal-open");
    if (returnFocus && typeof returnFocus.focus === "function") {
      returnFocus.focus({ preventScroll: true });
    }
    returnFocus = null;
  };

  openers.forEach(opener => opener.addEventListener("click", event => {
    event.preventDefault();
    openModal(opener);
  }));
  closers.forEach(closer => closer.addEventListener("click", closeModal));

  document.addEventListener("keydown", event => {
    if (modal.hidden) return;
    if (event.key === "Escape") {
      event.preventDefault();
      closeModal();
      return;
    }
    if (event.key !== "Tab") return;
    const items = focusable();
    if (!items.length) {
      event.preventDefault();
      dialog.focus();
      return;
    }
    const first = items[0];
    const last = items[items.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });
})();
