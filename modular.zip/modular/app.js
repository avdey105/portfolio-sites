'use strict';
(() => {
  const $ = selector => document.querySelector(selector);
  const menu = $('.menu-toggle');
  const closeMenu = () => { menu.setAttribute('aria-expanded', 'false'); menu.setAttribute('aria-label','Открыть меню'); $('#mobile-nav').hidden = true; };
  menu.addEventListener('click', () => { const open = menu.getAttribute('aria-expanded') !== 'true'; menu.setAttribute('aria-expanded', String(open)); menu.setAttribute('aria-label',open?'Закрыть меню':'Открыть меню'); $('#mobile-nav').hidden = !open; });
  $('#mobile-nav').addEventListener('click', e => { if (e.target.closest('a')) closeMenu(); });
  document.addEventListener('keydown', e => { if(e.key === 'Escape' && menu.getAttribute('aria-expanded') === 'true'){closeMenu();menu.focus();} });

  const scenarios = {
    country: {kicker:'Выходные в своём ритме',title:'Маленький дом.\nБольшая пауза.',description:'Для поездок на участок, тихих завтраков и вечеров, которые никуда не торопятся. Сначала определим сезонность и привычки, затем обсудим планировку.',check:'Обсудить: спальное место, хранение, санузел',purpose:'Дачный дом'},
    work: {kicker:'Место, где можно сосредоточиться',title:'Работа — рядом.\nСуета — снаружи.',description:'Отдельный кабинет на участке или бытовка для рабочей площадки. Важно понять, сколько людей будут внутри, какое оборудование понадобится и как организовать рабочий день.',check:'Обсудить: рабочие места, свет, розетки, вентиляцию',purpose:'Рабочий кабинет или бытовка'},
    guest: {kicker:'Быть рядом. И иметь своё место.',title:'Для своих.\nСо своим пространством.',description:'Гостевой модуль рядом с основным домом. Обсудите спальное место, хранение, приватность и необходимость собственного санузла.',check:'Обсудить: приватность, спальное место, воду',purpose:'Гостевой модуль'}
  };
  let selectedScenario = 'country';
  const tabs = [...document.querySelectorAll('[data-scenario]')];
  function chooseScenario(key) {
    selectedScenario = key; const data = scenarios[key];
    tabs.forEach(tab => {const selected=tab.dataset.scenario===key;tab.setAttribute('aria-selected',String(selected));tab.tabIndex=selected?0:-1;});
    $('#scenario-panel').setAttribute('aria-labelledby','tab-'+key);
    $('#scenario-kicker').textContent=data.kicker;
    $('#scenario-title').replaceChildren(...data.title.split('\n').flatMap((s,i)=>i?[document.createElement('br'),document.createTextNode(" "+s)]:[document.createTextNode(s)]));
    $('#scenario-description').textContent=data.description; $('#scenario-check').textContent=data.check;
  }
  tabs.forEach((tab,index) => {
    tab.addEventListener('click',()=>chooseScenario(tab.dataset.scenario));
    tab.addEventListener('keydown',e=>{let i=index;if(e.key==='ArrowDown'||e.key==='ArrowRight')i=(index+1)%tabs.length;else if(e.key==='ArrowUp'||e.key==='ArrowLeft')i=(index+tabs.length-1)%tabs.length;else if(e.key==='Home')i=0;else if(e.key==='End')i=tabs.length-1;else return;e.preventDefault();chooseScenario(tabs[i].dataset.scenario);tabs[i].focus();});
  });
  $('#choose-scenario').addEventListener('click', () => {
    const choice=[...document.querySelectorAll('[name="purpose"]')].find(e=>e.value===scenarios[selectedScenario].purpose); choice.checked=true;
    $('#brief-form').hidden=false;$('#brief-result').hidden=true;showStep(0,false);
  });

  const form = $('#brief-form'); const steps=[...document.querySelectorAll('.form-step')];let currentStep=0;
  function showStep(index,focus=true) {
    currentStep=index;steps.forEach((s,i)=>s.hidden=i!==index);
    $('#prev').hidden=index===0;$('#next').hidden=index===2;$('#generate').hidden=index!==2;$('#step-hint').hidden=index!==0;
    $('#step-label').textContent='Шаг '+String(index+1).padStart(2,'0')+' из 03';
    $('.form-counter').textContent=String(index+1).padStart(2,'0')+' — 03';
    [...$('.form-progress').children].forEach((li,i)=>{li.classList.toggle('active',i===index);li.classList.toggle('done',i<index);if(i===index)li.setAttribute('aria-current','step');else li.removeAttribute('aria-current');});
    if(focus){const legend=steps[index].querySelector('legend');legend.tabIndex=-1;legend.focus({preventScroll:true});if($('.brief-card').getBoundingClientRect().top<0)$('.brief-card').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});}
  }
  function validateStep(index) {for (const input of steps[index].querySelectorAll('input,select,textarea')){if(!input.checkValidity()){input.reportValidity();return false;}}return true;}
  $('#next').addEventListener('click',()=>{if(validateStep(currentStep))showStep(currentStep+1);});
  $('#prev').addEventListener('click',()=>showStep(Math.max(0,currentStep-1)));
  function syncQuantity(){const v=Number($('#quantity').value);$('#minus').disabled=Number.isFinite(v)&&v<=1;$('#plus').disabled=Number.isFinite(v)&&v>=1000;}
  function changeQuantity(delta){const q=$('#quantity');const n=Number(q.value);q.value=String(Math.max(1,Math.min(1000,(Number.isInteger(n)?n:1)+delta)));syncQuantity();}
  $('#minus').addEventListener('click',()=>changeQuantity(-1));$('#plus').addEventListener('click',()=>changeQuantity(1));$('#quantity').addEventListener('input',syncQuantity);syncQuantity();
  $('#wishes').addEventListener('input',()=>$('#char-count').textContent=$('#wishes').value.length+' / 800');
  form.addEventListener('keydown',e=>{if(e.key==='Enter' && e.target.tagName==='INPUT' && currentStep<2){e.preventDefault();$('#next').click();}});
  form.addEventListener('submit',e=>{
    e.preventDefault();for(let i=0;i<steps.length;i++){if(!validateStep(i)){showStep(i);return;}}
    const data=new FormData(form);const budget=data.get('budget');
    const text=['ПОЖЕЛАНИЯ К МОДУЛЬНОМУ ПРОСТРАНСТВУ','',
      'Назначение: '+data.get('purpose'),'Количество: '+data.get('quantity')+' шт.','Использование: '+data.get('season'),'Коммуникации: '+data.get('utilities'),'Регион размещения: '+(String(data.get('location')).trim()||'Нужно обсудить'),'Бюджет на модуль: '+(budget?Number(budget).toLocaleString('ru-RU')+' ₽ (пожелание заказчика)':'Нужно обсудить'),'Особые пожелания: '+(String(data.get('wishes')).trim()||'Не указаны'),'',
      'Требует согласования: итоговые размеры и планировка, материалы, утепление, инженерия, производитель, цена и налоги, доставка, разгрузка, основание, сроки и гарантия.','',
      'Это бриф для обсуждения, не заказ и не отправленная заявка. Визуализации на сайте — концепции, не фотографии товара.'].join('\n');
    $('#result-text').textContent=text;form.hidden=true;$('#brief-result').hidden=false;$('#step-label').textContent='Пожелания собраны';$('#copy-status').textContent='';$('#brief-result').focus({preventScroll:true});
  });
  $('#edit').addEventListener('click',()=>{form.hidden=false;$('#brief-result').hidden=true;showStep(0);});
  $('#download').addEventListener('click',()=>{const blob=new Blob(['\uFEFF'+$('#result-text').textContent],{type:'text/plain;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='Бриф — модульное пространство.txt';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);});
  $('#copy').addEventListener('click',async()=>{try{await navigator.clipboard.writeText($('#result-text').textContent);$('#copy-status').textContent='Бриф скопирован.';}catch{const selection=getSelection();const range=document.createRange();range.selectNodeContents($('#result-text'));selection.removeAllRanges();selection.addRange(range);$('#copy-status').textContent='Выделили текст. Нажмите Ctrl+C или скопируйте его через меню браузера.';}});
  if('IntersectionObserver' in window){
    if(!matchMedia('(prefers-reduced-motion: reduce)').matches){document.documentElement.classList.add('js-motion');const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target);}}),{threshold:.06});document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));}
    const briefObserver=new IntersectionObserver(entries=>$('.mobile-bottom').classList.toggle('is-hidden',entries[0].isIntersecting),{threshold:.05});briefObserver.observe($('#brief'));
  }
})();

