const navigation = document.querySelector('.main-nav');
const menuButton = document.querySelector('.nav-toggle');
const header = document.querySelector('.site-header');
const filterButtons = [...document.querySelectorAll('.filter-btn')];
const cards = [...document.querySelectorAll('.product-card')];
const catalogStatus = document.getElementById('catalog-status');
const productDialog = document.getElementById('product-dialog');
const dialogImage = productDialog.querySelector('.dialog-image');
const dialogTitle = document.getElementById('dialog-title');
const dialogDescription = productDialog.querySelector('.dialog-description');

function setMenu(open) {
  navigation.classList.toggle('is-open', open);
  menuButton.classList.toggle('is-open', open);
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
  document.body.classList.toggle('menu-open', open);
}

menuButton.addEventListener('click', () => setMenu(!navigation.classList.contains('is-open')));
navigation.querySelectorAll('a').forEach(link => link.addEventListener('click', () => setMenu(false)));
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && navigation.classList.contains('is-open')) {
    setMenu(false);
    menuButton.focus();
  }
});
const mobileLayout = window.matchMedia('(max-width: 860px)');
mobileLayout.addEventListener('change', event => {
  if (!event.matches) setMenu(false);
});

function syncHeader() {
  header.classList.toggle('is-scrolled', window.scrollY > 8);
}
syncHeader();
window.addEventListener('scroll', syncHeader, { passive: true });

function setFilter(activeButton) {
  const category = activeButton.dataset.filter;
  filterButtons.forEach(button => button.setAttribute('aria-pressed', String(button === activeButton)));
  let visibleCount = 0;
  cards.forEach(card => {
    card.hidden = category !== 'all' && card.dataset.category !== category;
    if (!card.hidden) visibleCount += 1;
  });
  catalogStatus.textContent = `Карточек в выбранной категории: ${visibleCount}`;
}

filterButtons.forEach(button => button.addEventListener('click', () => setFilter(button)));

cards.forEach(card => {
  card.querySelector('.card-detail').addEventListener('click', () => {
    const cover = card.querySelector('img');
    dialogImage.src = cover.getAttribute('src');
    dialogImage.alt = cover.alt;
    dialogTitle.textContent = card.querySelector('h3').textContent;
    dialogDescription.textContent = card.dataset.detail;
    productDialog.showModal();
  });
});
productDialog.querySelector('.dialog-close').addEventListener('click', () => productDialog.close());
productDialog.addEventListener('click', event => {
  if (event.target === productDialog) {
    const bounds = productDialog.getBoundingClientRect();
    if (event.clientX < bounds.left || event.clientX > bounds.right ||
        event.clientY < bounds.top || event.clientY > bounds.bottom) {
      productDialog.close();
    }
  }
});
