(() => {
  const dialog = document.querySelector('#partner-dialog');
  if (!dialog) return;
  let opener;

  document.querySelectorAll('[data-partner-open]').forEach((button) => {
    button.addEventListener('click', () => {
      opener = button;
      dialog.showModal();
      document.body.classList.add('dialog-open');
    });
  });

  dialog.querySelector('[data-partner-close]').addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', (event) => {
    if (event.target !== dialog) return;
    const rect = dialog.getBoundingClientRect();
    if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) {
      dialog.close();
    }
  });
  // Native <dialog> supplies focus containment and Escape-to-close.
  dialog.addEventListener('close', () => {
    document.body.classList.remove('dialog-open');
    opener?.focus();
  });
})();
