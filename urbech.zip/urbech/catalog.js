'use strict';

const products = [
  { id: 'pumpkin', title: 'Урбеч из тыквенных семян', label: 'Тыквенные семена', category: 'seeds', weight: 180, price: 510, art: 'green', backdrop: '#dce0c6', ingredients: 'Тыквенные семена', note: 'Густая паста с лёгкой травянистой ноткой. Подойдёт к каше, тостам и овощным соусам.' },
  { id: 'almond', title: 'Миндальный урбеч', label: 'Миндаль', category: 'nuts', weight: 180, price: 650, art: 'rust', backdrop: '#ead2bf', ingredients: 'Миндаль', note: 'Мягкая паста с миндальным вкусом. Попробуйте с фруктами или добавьте ложку в тесто для печенья.' },
  { id: 'sesame', title: 'Кунжутный урбеч', label: 'Кунжут', category: 'seeds', weight: 180, price: 490, art: 'sesame', backdrop: '#ece0bf', ingredients: 'Кунжут', note: 'Светлая паста с характерной кунжутной горчинкой. Подходит для заправок, хумуса и тостов.' },
  { id: 'flax', title: 'Урбеч из семян льна', label: 'Лён', category: 'seeds', weight: 180, price: 420, art: 'umber', backdrop: '#e4d2bd', ingredients: 'Семена льна', note: 'Плотная паста из молотого льна. Добавьте немного в йогурт, кашу или домашнюю гранолу.' },
  { id: 'cashew', title: 'Урбеч из кешью', label: 'Кешью', category: 'nuts', weight: 180, price: 620, art: 'pale', backdrop: '#eee2cd', ingredients: 'Кешью', note: 'Нежная паста со сливочной текстурой. Её можно использовать в сладких и солёных блюдах.' },
  { id: 'cacao', title: 'Фундук с какао', label: 'Какао и фундук', category: 'cacao', weight: 180, price: 690, art: 'cacao', backdrop: '#e3cfc2', ingredients: 'Фундук, какао', note: 'Ореховая паста с ярким вкусом какао. Попробуйте с блинами, бананом или печёным яблоком.' },
];

const categories = { all: 'Все', seeds: 'Семена', nuts: 'Орехи', cacao: 'С какао' };
const sorts = new Set(['catalog', 'price', 'name']);
const items = new Map(products.map(product => [product.id, product]));
const currency = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 0 });
const money = value => `${currency.format(value)} ₽`;
const normalize = value => value.trim().toLocaleLowerCase('ru-RU').replaceAll('ё', 'е');
const storageKey = 'portfolio-urbech-demo-cart-v1';

const ui = {
  filter: [...document.querySelectorAll('[data-category]')],
  search: document.querySelector('#query'),
  sort: document.querySelector('#sort'),
  cards: document.querySelector('#cards'),
  results: document.querySelector('#results-count'),
  feedback: document.querySelector('#feedback'),
  total: document.querySelector('[data-cart-count]'),
  cart: document.querySelector('#cart-dialog'),
  cartContent: document.querySelector('#cart-content'),
  product: document.querySelector('#product-dialog'),
  productContent: document.querySelector('#product-content'),
};

function filtersFromUrl() {
  const params = new URLSearchParams(window.location.search);
  const category = params.get('category');
  const sort = params.get('sort');
  return {
    query: (params.get('q') || '').slice(0, 100),
    category: Object.hasOwn(categories, category) ? category : 'all',
    sort: sorts.has(sort) ? sort : 'catalog',
  };
}

let filters = filtersFromUrl();
let cart = readCart();
let toastTimeout;
let openItem = null;

function readCart() {
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey));
    if (saved && typeof saved === 'object') {
      return new Map(Object.entries(saved).filter(([id, quantity]) => items.has(id) && Number.isInteger(quantity) && quantity > 0 && quantity <= 99));
    }
  } catch {
    // The demo still works in browsers that disallow local storage.
  }
  return new Map();
}

function setCartQuantity(id, quantity) {
  if (quantity > 0) cart.set(id, Math.min(quantity, 99));
  else cart.delete(id);
  saveCart();
}

function saveCart() {
  try {
    localStorage.setItem(storageKey, JSON.stringify(Object.fromEntries(cart)));
  } catch {
    // The in-memory cart remains available for the current visit.
  }
  renderCart();
}

function pageUrl(productId = '', hash = window.location.hash) {
  const url = new URL(window.location.href);
  url.search = '';
  url.hash = hash;
  if (filters.query.trim()) url.searchParams.set('q', filters.query.trim());
  if (filters.category !== 'all') url.searchParams.set('category', filters.category);
  if (filters.sort !== 'catalog') url.searchParams.set('sort', filters.sort);
  if (productId) url.searchParams.set('product', productId);
  return `${url.pathname}${url.search}${url.hash}`;
}

function jarMarkup(product) {
  return `<span class="jar jar-${product.art}" aria-hidden="true"><span class="jar-lid"></span><span class="jar-label"><span class="jar-maker">урбеч<span>.</span></span><span class="jar-flavor">${product.label}</span><span class="jar-weight">${product.weight} г</span></span></span>`;
}

function cardMarkup(product) {
  const link = pageUrl(product.id, '#catalog').replaceAll('&', '&amp;');
  return `<article class="product-card" data-card="${product.id}">
    <a class="product-art" data-product="${product.id}" href="${link}" aria-label="Подробнее: ${product.title}" style="--art-background:${product.backdrop}">${jarMarkup(product)}</a>
    <div class="product-info">
      <p class="product-meta">${categories[product.category]} · ${product.weight} г</p>
      <h3><a href="${link}" data-product="${product.id}">${product.title}</a></h3>
      <div class="product-actions"><span class="price">${money(product.price)}</span><button class="button secondary" data-add="${product.id}" type="button" aria-label="В корзину: ${product.title}">В корзину</button></div>
    </div>
  </article>`;
}

function renderCatalog() {
  ui.search.value = filters.query;
  ui.sort.value = filters.sort;
  for (const button of ui.filter) {
    button.setAttribute('aria-pressed', String(button.dataset.category === filters.category));
  }
  const queryParts = normalize(filters.query).split(/\s+/).filter(Boolean);
  const results = products.filter(product => {
    const searchable = normalize(`${product.title} урбеч ${product.label} ${product.ingredients} ${categories[product.category]}`);
    return (filters.category === 'all' || product.category === filters.category) && queryParts.every(part => searchable.includes(part));
  });
  if (filters.sort === 'name') results.sort((a, b) => a.title.localeCompare(b.title, 'ru-RU'));
  if (filters.sort === 'price') results.sort((a, b) => a.price - b.price);

  ui.results.textContent = `Найдено: ${results.length}`;
  ui.cards.innerHTML = results.length ? results.map(cardMarkup).join('') : `
    <div class="empty"><p>По этому запросу ничего нет.</p><button class="button secondary" type="button" data-reset>Сбросить фильтры</button></div>`;
}

function updateFilters(patch) {
  filters = { ...filters, ...patch };
  history.replaceState(history.state, '', pageUrl(openItem || ''));
  renderCatalog();
}

function renderCart() {
  ui.total.textContent = [...cart.values()].reduce((sum, count) => sum + count, 0);
  ui.cartContent.innerHTML = !cart.size ? `
    <div class="cart-empty"><p>Корзина пока пуста.</p><button class="button secondary" type="button" data-cart-browse>Вернуться в каталог</button></div>` : `
    <ul class="cart-list">
      ${[...cart].map(([id, count]) => {
        const product = items.get(id);
        return `<li class="cart-row" data-cart-row="${id}">
          <span class="cart-row-name">${product.title}<small>${product.weight} г</small></span>
          <span class="qty"><button type="button" data-quantity="decrement" data-id="${id}" aria-label="Уменьшить количество: ${product.title}">−</button><output aria-label="Количество">${count}</output><button type="button" data-quantity="increment" data-id="${id}" aria-label="Увеличить количество: ${product.title}">+</button></span>
          <span class="price">${money(product.price * count)}</span>
        </li>`;
      }).join('')}
    </ul>
    <p class="cart-total"><span>Итого</span><span class="price" data-total>${money([...cart].reduce((sum, [id, count]) => sum + items.get(id).price * count, 0))}</span></p>
    <div class="cart-footer"><p>Это пробная корзина. Заказ и оплата недоступны.</p><button class="button secondary" type="button" data-cart-clear>Очистить</button></div>`;
}

function addToCart(id) {
  setCartQuantity(id, (cart.get(id) || 0) + 1);
  clearTimeout(toastTimeout);
  ui.feedback.textContent = 'Товар добавлен в корзину';
  toastTimeout = setTimeout(() => { ui.feedback.textContent = ''; }, 2300);
  if (ui.product.open) {
    ui.productContent.querySelector('[data-product-feedback]').textContent = 'Добавлено в корзину';
  }
}

function showProduct(id, navigate = false) {
  const product = items.get(id);
  if (!product) return;
  if (navigate && openItem !== id) {
    history.pushState({ urbechProduct: true }, '', pageUrl(id, '#catalog'));
  }
  openItem = id;
  ui.productContent.innerHTML = `<div class="product-dialog-layout">
    <div class="product-art" aria-hidden="true" style="--art-background:${product.backdrop}">${jarMarkup(product)}</div>
    <div class="product-copy">
      <p class="product-meta">${categories[product.category]} · ${product.weight} г · Демотовар</p>
      <h2 id="product-title">${product.title}</h2>
      <p>${product.note}</p><p><strong>Состав</strong> · ${product.ingredients}</p>
      <div class="product-actions"><span class="price">${money(product.price)}</span><button class="button primary" data-add="${id}" type="button">В корзину</button></div>
      <p class="product-meta" role="status" data-product-feedback></p>
    </div>
  </div>`;
  if (!ui.product.open) ui.product.showModal();
}

ui.search.maxLength = 100;
ui.search.addEventListener('input', event => updateFilters({ query: event.target.value }));
ui.sort.addEventListener('change', event => updateFilters({ sort: event.target.value }));

document.addEventListener('click', event => {
  const target = event.target.closest('[data-category], [data-add], [data-product], [data-cart-open], [data-cart-clear], [data-cart-browse], [data-quantity], [data-close], [data-reset]');
  if (!target) return;
  if (target.hasAttribute('data-category')) updateFilters({ category: target.dataset.category });
  if (target.hasAttribute('data-reset')) {
    updateFilters({ query: '', category: 'all', sort: 'catalog' });
    ui.search.focus();
  }
  if (target.hasAttribute('data-add')) addToCart(target.dataset.add);
  if (target.hasAttribute('data-product') && event.button === 0 && !event.ctrlKey && !event.metaKey && !event.shiftKey && !event.altKey) {
    event.preventDefault();
    showProduct(target.dataset.product, true);
  }
  if (target.hasAttribute('data-cart-open')) {
    renderCart();
    ui.cart.showModal();
  }
  if (target.hasAttribute('data-quantity')) {
    const { id, quantity } = target.dataset;
    const step = quantity === 'increment' ? 1 : -1;
    setCartQuantity(id, (cart.get(id) || 0) + step);
    const button = ui.cartContent.querySelector(`[data-id="${id}"][data-quantity="${quantity}"]`);
    (button || ui.cartContent.querySelector('button'))?.focus();
  }
  if (target.hasAttribute('data-cart-clear')) {
    cart.clear();
    saveCart();
    ui.cartContent.querySelector('button')?.focus();
  }
  if (target.hasAttribute('data-cart-browse')) {
    ui.cart.close();
    document.querySelector('#catalog').scrollIntoView();
    ui.search.focus({ preventScroll: true });
  }
  if (target.hasAttribute('data-close')) ui[target.dataset.close].close();
});

ui.product.addEventListener('close', () => {
  if (!openItem) return;
  openItem = null;
  if (history.state?.urbechProduct) history.back();
  else history.replaceState(history.state, '', pageUrl());
});

window.addEventListener('popstate', () => {
  filters = filtersFromUrl();
  openItem = null;
  const id = new URLSearchParams(window.location.search).get('product');
  if (items.has(id)) showProduct(id);
  else if (ui.product.open) ui.product.close();
  renderCatalog();
});

window.addEventListener('storage', event => {
  if (event.key === storageKey) {
    cart = readCart();
    renderCart();
  }
});

renderCatalog();
renderCart();
showProduct(new URLSearchParams(window.location.search).get('product'));
